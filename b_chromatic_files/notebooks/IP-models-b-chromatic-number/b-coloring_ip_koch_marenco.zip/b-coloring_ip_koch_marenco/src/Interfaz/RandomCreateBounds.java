package Interfaz;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;

public class RandomCreateBounds {
	// Funcion principal para ejecutar una instancia
	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/boundsRandom"), "utf-8"));
		for (int n = 10; n < 160; n += 10) {
			for (int d = 1; d < 9; d++) {
				// if (n == 20 && d == 2) {
				String nombreGrafo = "G_" + n + "_" + d;

				Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
				int upperBound = BColUpperBound.upperBound(g);
				DSATUR dsatur = new DSATUR(g);
				int lowerBound = GraphColoringUtils.coloresUsados(dsatur.color());

				writer.write(nombreGrafo + " ");
				int[] coloresParaProbar = { lowerBound, (lowerBound + upperBound) / 2, upperBound };
				for (int colores : coloresParaProbar) {
					writer.write(colores + " ");

				}
				writer.write("\n");
				writer.flush();
			}

		}
		writer.close();

	}
}
