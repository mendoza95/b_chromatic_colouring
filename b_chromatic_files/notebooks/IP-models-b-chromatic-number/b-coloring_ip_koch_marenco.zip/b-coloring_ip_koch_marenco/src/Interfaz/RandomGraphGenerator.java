package Interfaz;

import test.aux.GraphGenerator;
import b.col.solver.GraphUtils;

public class RandomGraphGenerator {
	// Funcion principal para ejecutar una instancia
	public static void main(String[] args) throws Exception {

		for (int n = 10; n < 160; n+=10) {
			for (int d = 1; d < 9; d++)
				//System.out.println("G_" + n + "_" + d);
				GraphUtils.saveToTxt("./random/G_" + n + "_" + d, GraphGenerator.randomGraph(n, d / 10.0));
		}
	}

}
