package Interfaz;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

//formatear el log.

public class LogFormatter extends Formatter {

	// Esto se llama para formatear lo que logueamos. Sí, en Java es todo difícil, la gran puta.

	public String format(LogRecord rec) {

		return rec.getMessage();
	
	}
}
