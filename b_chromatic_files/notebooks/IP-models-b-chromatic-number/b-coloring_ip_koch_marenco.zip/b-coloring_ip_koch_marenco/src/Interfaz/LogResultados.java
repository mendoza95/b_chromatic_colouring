package Interfaz;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LogResultados {


	 public static void setup() throws IOException {

		// configuramos el logger global.

		Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

		logger.setLevel(Level.ALL);

		FileHandler fileTxt = new FileHandler("LogResultados.txt");
		
		fileTxt.setLevel(Level.ALL);
		fileTxt.setFormatter(new LogFormatter());
		
	    FileHandler fileTxt2 = new FileHandler("LogResultadosDetalle.txt");
		
		fileTxt2.setLevel(Level.ALL);
		fileTxt2.setFormatter(new LogFormatter());

		for (Handler h : logger.getHandlers())
			logger.removeHandler(h);

		logger.setUseParentHandlers(false);

		logger.addHandler(fileTxt);
		logger.addHandler(fileTxt2);
	}
	
	
}
