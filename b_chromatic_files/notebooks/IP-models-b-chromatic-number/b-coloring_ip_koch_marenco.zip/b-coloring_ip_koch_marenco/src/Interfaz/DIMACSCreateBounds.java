package Interfaz;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

import test.aux.TestUtils;
import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;

public class DIMACSCreateBounds {
	// Funcion principal para ejecutar una instancia
	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/boundsDimacsIztok"), "utf-8"));
		// String directory = "./tester";
		String directory = "./instances-dimacs/instances-iztok";

		DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));

		for (Path p : ds) {
			FileOutputStream out = null;
			try {
				if (Files.isDirectory(p))
					continue;
				// Iteramos por todos los archivos del directorio y resolvemos
				Grafo g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + p.getFileName());
				// Grafo g = GraphUtils.loadFromTxt(directory +
				// FileSystems.getDefault().getSeparator() + p.getFileName());

				System.out.println(p.getFileName().toString());
				int upperBound = BColUpperBound.upperBound(g);
				DSATUR dsatur = new DSATUR(g);

				int lowerBound = GraphColoringUtils.coloresUsados(dsatur.color());
				writer.write(p.getFileName().toString() + " ");
				int[] coloresParaProbar = { lowerBound, (lowerBound + upperBound) / 2, upperBound };
				for (int colores : coloresParaProbar) {
					writer.write(colores + " ");
					
				}
				writer.write("\n");
				writer.flush();

			} catch (Exception ex) {
				ex.printStackTrace();

			} finally {
				if (out != null)
					out.close();
				System.gc();

			}
		}
		writer.close();
	}
}
