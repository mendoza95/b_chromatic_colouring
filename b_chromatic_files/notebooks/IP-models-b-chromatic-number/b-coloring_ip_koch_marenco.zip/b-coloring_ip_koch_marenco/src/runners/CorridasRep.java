package runners;

import b.col.solver.modelo.standard.Configuracion;

public class CorridasRep {

	public static Configuracion runSinCortes(double time, String solucion) throws Exception {
		// con cortes clique
		Configuracion configuracion = new Configuracion();
		configuracion.timeLim = time;
		configuracion.rconCuts = false;
		configuracion.rInitialSol = true;
		configuracion.rfileNameSol = solucion;

		return configuracion;
	}
	
	public static Configuracion runSinSolInicial(double time) throws Exception {
		// con cortes clique
		Configuracion configuracion = new Configuracion();
		configuracion.timeLim = time;
		configuracion.rconCuts = false;
		configuracion.rInitialSol = false;		

		return configuracion;
	}

}
