package runners;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.FileSystems;
import java.util.Map;

import test.aux.TestUtils;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class Single {

	private static boolean DIMACS = true;

	// Funcion principal para ejecutar una instancia
	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/logSingle"), "utf-8"));
		String directory = "./instances-dimacs/phase1";
		// String directory = "./random";
		String nombreGrafo = "homer.col";

		Grafo g;
		String boundsFileName = "./logs/boundsRandom";
		if (DIMACS)
			boundsFileName = "./logs/boundsDimacs";

		if (DIMACS)
			g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);
		else
			g = GraphUtils.loadFromTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

		// int colores = 12;

		Map<String, int[]> bounds = GraphColoringUtils.uploadBounds(boundsFileName);

		int lowerBound = bounds.get(nombreGrafo)[0];
		int medBound = bounds.get(nombreGrafo)[1];
		int upperBound = bounds.get(nombreGrafo)[2];
		int[] coloresParaProbar = { lowerBound, medBound, upperBound };
		//int[] coloresParaProbar = { medBound };
		int colorAnterior = -1;

		for (int colores : coloresParaProbar) {

			FileOutputStream out = null;
			try {
				if (colores > colorAnterior) {

					out = new FileOutputStream("./logs/LogDetalleSingle_" + nombreGrafo + "c" + colores);

					//Configuracion config = CorridasStandard.runSinReducir(1800, out, g, colores);

					Configuracion config = CorridasStandard.runConTodosLosCortes(1800, out, g, colores);
					//Configuracion config = CorridasStandard.runSinCortes(1800, out, g, colores);
					
					BColModelStandard model = new BColModelStandard(g, colores);

					Solucion sol = model.solve(config, out);

					if (sol != null)
						sol.toTxt("./logs/soluciones-standard/Sol_" + nombreGrafo);

					String log = TestUtils.printResults(nombreGrafo, colores, config);

					writer.write(log + "\n");
					writer.flush();

					GlobalStatistics.getInstance().clear();
				}

			} catch (Exception ex) {
				ex.printStackTrace();

			} finally {
				if (out != null)
					out.close();
				System.gc();
				colorAnterior = colores;
			}
		}

		writer.close();

	}
}
