package runners;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import test.aux.TestUtils;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class StandardMany {
	// Funcion principal para ejecutar una instancia

	private static boolean DIMACS = true;

	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/logs-iztok/logGeneral"), "utf-8"));
		//Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./tester-logs/logGeneral"), "utf-8"));
		String directory;
		if (DIMACS)
			directory = "./instances-dimacs/instances-iztok";
		else
			directory = "./random-sparse";
			//directory = "./tester";
		DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));

		String boundsFileName = "./logs/boundsRandom";
		if (DIMACS)
			boundsFileName = "./logs/boundsDimacsIztok";

		Map<String, int[]> bounds = GraphColoringUtils.uploadBounds(boundsFileName);

		for (Path p : ds) {

			if (Files.isDirectory(p))
				continue;
			// Iteramos por todos los archivos del directorio y resolvemos
			Grafo g;
			String nombreGrafo = p.getFileName().toString();
			if (DIMACS)
				g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);
			else
				g = GraphUtils.loadFromTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

			int lowerBound = bounds.get(nombreGrafo)[0];
			int medBound = bounds.get(nombreGrafo)[1];
			int upperBound = bounds.get(nombreGrafo)[2];
			int[] coloresParaProbar = { lowerBound, medBound, upperBound };
			int colorAnterior = -1;

			for (int colores : coloresParaProbar) {
				FileOutputStream out = null;
				try {
					if (colores > colorAnterior) {

						out = new FileOutputStream("./logs/logs-iztok/Log_" + nombreGrafo + "c" + colores);
						

						// Configuracion configuracionConCortes =
						// Corridas.runConCortesClique(900, out, g, colores);
						//Configuracion configuracionConCortes = Corridas.runSinCortes(600, out, g, colores);
						//Con
						//Configuracion configuracion = CorridasStandard.runSinCortes(1800, out, g, colores);
						Configuracion configuracion = CorridasStandard.runConTodosLosCortes(10800, out, g, colores);
						
						BColModelStandard model = new BColModelStandard(g, colores);
						Solucion sol = model.solve(configuracion, out);

//						if (!sol.esBColoreo())
//							throw new RuntimeException("Solucion no valida, no es b col");
//						if (sol != null)
//							sol.toTxt("./logs/logs-standard-dimacs-con-cuts-v2/Sol_" + nombreGrafo + "c" + colores);
//						

						String log = TestUtils.printResults(nombreGrafo, colores, configuracion);

						writer.write(log + "\n");
						writer.flush();

						GlobalStatistics.getInstance().clear();
					}
					
				} catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					colorAnterior = colores;
					if (out != null)
						out.close();
					System.gc();
				}

			}
		}

		writer.close();
	}
}
