package runners;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.FileSystems;

import test.aux.TestUtils;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.representantes.BColModelRepresentatives;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class SingleRep {

	private static boolean DIMACS = true;

	// Funcion principal para ejecutar una instancia
	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/logs-iztok/logSingle"), "utf-8"));
		String directory = "./instances-dimacs/instances-iztok";
		// String directory = "./random";
		String nombreGrafo = "DSJC250.5.col";

		FileOutputStream out = null;
		try {
			Grafo g;
			
			if (DIMACS)
				g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);
			else
				g = GraphUtils.loadFromTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

		
			out = new FileOutputStream("./logs/logs-iztok/LogDetalleSingleRep_" + nombreGrafo);

			//Configuracion config = CorridasRep.runSinCortes(1800, "./logs/soluciones-standard/Sol_" + nombreGrafo);
			Configuracion config = CorridasRep.runSinSolInicial(10800);


			BColModelRepresentatives model = new BColModelRepresentatives(g);

			Solucion sol = model.solve(config, out);

			String log = TestUtils.printResults(nombreGrafo, sol.getColores(), config);

			writer.write(log + "\n");
			writer.flush();

			GlobalStatistics.getInstance().clear();

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			if (out != null)
				out.close();
			System.gc();

		}

		writer.close();
	}

}
