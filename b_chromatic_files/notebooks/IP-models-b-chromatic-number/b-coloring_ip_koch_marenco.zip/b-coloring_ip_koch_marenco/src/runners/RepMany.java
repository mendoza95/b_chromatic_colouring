package runners;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import test.aux.TestUtils;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.representantes.BColModelRepresentatives;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class RepMany {
	// Funcion principal para ejecutar una instancia

	private static boolean DIMACS = true;

	public static void main(String[] args) throws Exception {

		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("./logs/logs-iztok/logGeneral"), "utf-8"));
		// Writer writer = new BufferedWriter(new OutputStreamWriter(new
		// FileOutputStream("./tester-logs/logGeneral"), "utf-8"));
		String directory;
		if (DIMACS)
			directory = "./instances-dimacs/instances-iztok";
		else
			directory = "./random-sparse";
		// directory = "./tester";
		DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));

			
		for (Path p : ds) {
			FileOutputStream out = null;
			try {
				if (Files.isDirectory(p))
					continue;
				// Iteramos por todos los archivos del directorio y resolvemos
				Grafo g;
				String nombreGrafo = p.getFileName().toString();
				if (DIMACS)
					g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);
				else
					g = GraphUtils.loadFromTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

				out = new FileOutputStream("./logs/logs-iztok/Log_" + nombreGrafo);

				Configuracion configuracion = CorridasRep.runSinSolInicial(10800);

				BColModelRepresentatives model = new BColModelRepresentatives(g);
				Solucion sol = model.solve(configuracion, out);

				String log = TestUtils.printResults(nombreGrafo, sol.getColores(), configuracion);

				writer.write(log + "\n");
				writer.flush();

				GlobalStatistics.getInstance().clear();

			} catch (Exception ex) {
				System.out.println("La concha de la lora!");
				ex.printStackTrace();				
			} finally {

				if (out != null)
					out.close();
				System.gc();
			}

		}

		writer.close();
	}
}
