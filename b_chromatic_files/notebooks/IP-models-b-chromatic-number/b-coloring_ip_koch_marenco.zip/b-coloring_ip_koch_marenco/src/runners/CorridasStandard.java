package runners;

import java.io.FileOutputStream;

import b.col.solver.Grafo;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class CorridasStandard {

	public static Configuracion runConCortesClique(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = false;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = false;
		configuracionConCortes.conCortesClique = true;
		configuracionConCortes.graphReduction = true;
		configuracionConCortes.initialSol = true;

		return configuracionConCortes;
	}

	public static Configuracion runConTodosLosCortes(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = true;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = true;
		configuracionConCortes.conCortesClique = true;
		configuracionConCortes.graphReduction = true;
		configuracionConCortes.initialSol = true;

		return configuracionConCortes;

	}
	

	public static Configuracion runConTodosLosCortesSinRed(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = true;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = true;
		configuracionConCortes.conCortesClique = true;
		configuracionConCortes.graphReduction = false;
		configuracionConCortes.initialSol = true;

		return configuracionConCortes;

	}


	public static Configuracion runSinReducir(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = true;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = true;
		configuracionConCortes.conCortesClique = true;
		configuracionConCortes.graphReduction = false;
		configuracionConCortes.initialSol = true;

		return configuracionConCortes;

	}
	public static Configuracion runConCortesTipo2(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = true;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = false;
		configuracionConCortes.conCortesClique = false;
		configuracionConCortes.graphReduction = true;
		configuracionConCortes.initialSol = true;

		return configuracionConCortes;
	}

	public static Configuracion runSinCortes(double time, FileOutputStream out, Grafo g, int colores) throws Exception {
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = time;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = false;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = false;
		configuracionConCortes.conCortes3y4 = false;
		configuracionConCortes.conCortes5 = false;
		configuracionConCortes.conCortesClique = false;
		configuracionConCortes.graphReduction = false;
		configuracionConCortes.initialSol = false;

		return configuracionConCortes;
	}

}
