package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class CutGenerator extends IloCplex.UserCutCallback {
	
	//private static final double SEPARAR_CADA = 20;
	
	private IloCplex cplex;
	private BColModelRepresentatives model;

	// Numero de activacion
	private static int activacion = 0;

	public CutGenerator(IloCplex cplex, BColModelRepresentatives model) {
		this.cplex = cplex;
		this.model = model;
	}

	@Override
	protected void main() throws IloException {
		// Genera la solucion
		int n = model.getG().getVertices();

		activacion++;

		// Ejecuta la separacion
		if (activacion % model.getConfiguracion().cortarCada == 0) {
			SolucionFraccionaria solucion = new SolucionFraccionaria(this.model.getG());

			for (int v = 0; v < n; ++v)
				for (int w = 0; w < n; ++w)
					if (this.model.getValidX()[v][w])
						solucion.setX(v, w, this.getValue(this.model.getX()[v][w]));

			System.err.println("Procedimiento de separacion, activacion " + activacion);
			Separator separator = new Separator(model.getG(), model.getConfiguracion(), solucion);
			separator.separar();

			// Agrega las desigualdades
			for (Desigualdad dv : separator.getDesigualdades()) {
				// dv.mostrar(solucion);

				// if( dv.porcentajeViolacion(solucion) < 0.05 )
				// continue;
				this.add(dv.buildCut(cplex, model));
				// IloNumExpr cut = cplex.linearIntExpr();
				// cut = cplex.sum(cut, cplex.prod(dv.getCoeficienteZ(),
				// model.getZ()[dv.getZ()][dv.getC()]));
				//
				// for (int v = 0; v < n; ++v)
				// for (int c = 0; c < colores; ++c)
				// cut = cplex.sum(cut, cplex.prod(dv.getCoeficienteX(v, c),
				// model.getX()[v][c]));
				//
				// this.add(cplex.le(cut, dv.getRhs()));
			}
		}

	}
}
