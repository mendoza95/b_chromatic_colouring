package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.HashSet;
import java.util.Set;

import b.col.solver.Grafo;

public class DesigualdadTipo3 extends AbstractDesigualdad {

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int v;
	private int u;
	private int w;
	private Set<Integer> NuIntNv;
	private Set<Integer> NuMinusNv;		
	

	// Constructor
	public DesigualdadTipo3(Grafo g, int v, int u, int w) {

		super(g, 2);
		this.v = v;
		this.u = u;
		this.w = w;
		
		this.NuIntNv = new HashSet<Integer>(g.getVecinos(v));
		this.NuIntNv.retainAll(g.getVecinos(u));
		
		this.NuMinusNv = new HashSet<Integer>(g.getVecinos(u));
		this.NuMinusNv.removeAll(g.getVecinos(v));

		if (g.getDistancia(u, v) != 2)
			throw new RuntimeException("La distancia entre u y v no puede ser distinta de 2");
	}

	public IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException {

		IloNumExpr cut = cplex.linearIntExpr();

		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, v), model.getX()[v][v]));

		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(u, u), model.getX()[u][u]));
		
		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(w, w), model.getX()[w][w]));

		for (int z = 0; z < n; z++)
			if (z != u && z != v && model.getValidX()[w][z])
				cut = cplex.sum(cut, cplex.prod(getCoeficienteX(w, z), model.getX()[w][z]));
				
		return cplex.le(cut, this.rhs);
	}

	public double getCoeficienteX(int i, int j) {

		checkRange(i);
		checkRange(j);
		
		if (i == j)
			if	(i == v || i == u)
				return 1;
			else
				if (i == w)
					if (this.NuIntNv.contains(j) || this.NuMinusNv.contains(j))
						return 0;
					else
						return 0;
				else 
					return 0;
		
		else
			return 0;
	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteX(v, v) * solucion.getX(v, v);

		_lhs += getCoeficienteX(u, u) * solucion.getX(u, u);
		
		_lhs += getCoeficienteX(w, w) * solucion.getX(w, w);
		
		for (int z = 0; z < n; z++)
			if (z != u && z != v)
				_lhs += getCoeficienteX(w, z) * solucion.getX(w, z);

		return _lhs;
	}
}
