package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.Set;

import b.col.solver.Grafo;

public class DesigualdadTipo1 extends AbstractDesigualdad {

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int v;
	private int c;
	private Set<Integer> Nv;

	// Constructor
	public DesigualdadTipo1(Grafo g, int v, int c, int colores) {

		super(g.getVertices(), colores, 0);

		this.c = c;
		this.v = v;
		this.Nv = g.getVecinos(v);
		if (g.getGrado(v) < colores)
			throw new RuntimeException("v no puede ser dominante");

	}

	@Override
	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException {
		IloNumExpr cut = cplex.linearIntExpr();
		cut = cplex.sum(cut, cplex.prod(getCoeficienteZ(v, c), model.getZ()[v][c]));

		for (int w : Nv)
			for (int cPrime = 0; cPrime < colores; ++cPrime)
				if (cPrime != c)
					cut = cplex.sum(cut, cplex.prod(this.getCoeficienteX(w, cPrime), model.getX()[w][cPrime]));

		return cplex.le(cut, this.rhs);
	}

	@Override
	public double getCoeficienteZ(int i, int c) {

		checkRange(i, c);

		if (i == this.v && c == this.c)
			return colores - 1;
		else
			return 0;
	}

	@Override
	public double getCoeficienteX(int i, int c) {

		checkRange(i, c);

		if (!Nv.contains(i))
			return 0;
		else if (c == this.c)
			return 0;
		else
			return -1;
	}

	// Consulta el LHS en la solucion indicada
	@Override
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteZ(v, c) * solucion.getZ(v, c);

		for (int w: Nv)
			for (int c = 0; c < colores; ++c)
				_lhs += getCoeficienteX(w, c) * solucion.getX(w, c);

		return _lhs;
	}

	// Vertices con coeficientes no nulos
	// public Set<Integer> getSoporte() {
	// Set<Integer> ret = new HashSet<Integer>();
	// for (int i = 0; i < _n; ++i)
	// if (getCoeficiente(i) != 0)
	// ret.add(i);
	//
	// return ret;
	// }

}
