package b.col.solver.modelo.representantes;

import java.util.HashSet;
import java.util.Set;

import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.modelo.standard.Configuracion;

public class Separator {

	private SolucionFraccionaria solucion;

	private Set<Desigualdad> desigualdades;

	private Grafo g;

	private static final double MAXTOL = 0.7;
	private static final double MINVALU = 0.05;

	private int desTipo1 = 0;
	private int desTipo2 = 0;
	private int desTipo3 = 0;
	private int desClique = 0;

	public Separator(Grafo g, Configuracion configuracion, SolucionFraccionaria solucion) {

		this.solucion = solucion;
		this.g = g;
		this.desigualdades = new HashSet<Desigualdad>();
	}

	public void separar() {

		// separarTipo1();
		// separarTipo2();
		separarCliques();
	}

	private boolean inTol(int v) {
		return solucion.getX(v, v) >= 1 - MAXTOL;
	}

	public void separarCliques() {

		for (Set<Integer> clique : g.getCliques()) {
			for (int v = 0; v < g.getVertices(); v++) {
				if (!clique.contains(v)) {
					DesigualdadClique dc = new DesigualdadClique(g, v, clique);
					if (dc.violada(solucion)) {
						desigualdades.add(dc);
						desClique++;
					}
				}
			}
		}

		GlobalStatistics.getInstance().cortesClique += desClique;
		System.err.println("  -> " + desClique + " desigualdades violadas clique agregadas a cplex");
	}

	public void separarTipo3() {

		for (int v = 0; v < g.getVertices(); v++) {
			for (int u = v + 1; u < g.getVertices(); u++)
				for (int w = 0; w < g.getVertices(); w++)
					if (w != v && w != u && inTol(u) && inTol(v) && inTol(w) && g.getDistancia(u, v) == 2) {
						DesigualdadTipo3 d3 = new DesigualdadTipo3(g, v, u, w);
						if (d3.violada(solucion)) {
							desigualdades.add(d3);
							desTipo3++;
						}
						DesigualdadTipo3 d3b = new DesigualdadTipo3(g, u, v, w);
						if (d3b.violada(solucion)) {
							desigualdades.add(d3b);
							desTipo3++;
						}
					}

		}
		GlobalStatistics.getInstance().cortesTipo3 += desTipo3;		
		System.err.println("  -> " + desTipo3 + " desigualdades violadas de tipo 3 agregadas a cplex");
	}

	public void separarTipo2() {

		for (int v = 0; v < g.getVertices(); v++) {
			if (solucion.getX(v, v) >= 1 - MAXTOL) {
				DesigualdadTipo2 d2 = new DesigualdadTipo2(g, v);
				if (d2.violada(solucion)) {
					desigualdades.add(d2);
					desTipo2++;
				}
			}

		}
		GlobalStatistics.getInstance().cortesTipo2 += desTipo2;
		System.err.println("  -> " + desTipo2 + " desigualdades violadas de tipo 2 agregadas a cplex");
	}

	public void separarTipo1() {

		// double max = Integer.MIN_VALUE;
		Set<Integer> U = new HashSet<Integer>();
		for (int v = 0; v < g.getVertices(); v++) {
			// if (val > max) {
			// maxV = v;
			// max = val;
			// }
			if (solucion.getX(v, v) >= 1 - MAXTOL) {

				U.clear();

				for (int u = 0; u < g.getVertices(); u++) {
					Set<Integer> Nv = g.getVecinos(v);
					double sumValU = 0;
					for (int w : Nv)
						sumValU += solucion.getX(u, w);

					if (solucion.getX(u, u) >= sumValU && u != v)
						U.add(u);
				}

				if (!U.isEmpty()) {
					DesigualdadTipo1 d1 = new DesigualdadTipo1(g, v, U);
					if (d1.violada(solucion)) {
						desigualdades.add(d1);
						desTipo1++;
					}
				}

				GlobalStatistics.getInstance().cortesTipo1 += desTipo1;
				System.err.println("  -> " + desTipo1 + " desigualdades violadas de tipo 1 agregadas a cplex");
			}
		}
	}

	public Set<Desigualdad> getDesigualdades() {
		return desigualdades;
	}

}
