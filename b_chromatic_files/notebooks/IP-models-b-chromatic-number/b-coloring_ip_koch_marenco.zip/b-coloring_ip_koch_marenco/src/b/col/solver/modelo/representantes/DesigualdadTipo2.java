package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import b.col.solver.Grafo;

public class DesigualdadTipo2 extends AbstractDesigualdad {

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int v;

	// Constructor
	public DesigualdadTipo2(Grafo g, int v) {

		super(g, 0);
		this.v = v;
	}

	public IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException {

		int n = g.getVertices();
		IloNumExpr cut = cplex.linearIntExpr();

		for (int w = 0; w < n; w++)
			if (model.getValidX()[v][w])
				cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, w), model.getX()[v][w]));

		for (int u = 0; u < n; u++)
			if (u != v)
				cut = cplex.sum(cut, cplex.prod(getCoeficienteX(u, u), model.getX()[u][u]));

		return cplex.le(cut, this.rhs);
	}

	public double getCoeficienteX(int i, int j) {

		checkRange(i);
		checkRange(j);

		if (i == j && i != v)
			return 1;
		else if (i == v)
			return -g.getGrado(j);
		else
			return 0;

	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		for (int w = 0; w < n; w++)
			_lhs += getCoeficienteX(v, w) * solucion.getX(v, w);

		for (int u = 0; u < n; u++)
			if (u != v)
				_lhs += getCoeficienteX(u, u) * solucion.getX(u, u);

		return _lhs;
	}
}
