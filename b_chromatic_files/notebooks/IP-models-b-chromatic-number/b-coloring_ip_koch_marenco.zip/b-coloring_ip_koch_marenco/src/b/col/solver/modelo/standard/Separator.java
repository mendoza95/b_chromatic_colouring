package b.col.solver.modelo.standard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.management.RuntimeErrorException;

import org.javatuples.Pair;

import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.modelo.standard.SolucionFraccionaria.VariableX;
import b.col.solver.modelo.standard.SolucionFraccionaria.VariableZ;

public class Separator {

	private SolucionFraccionaria solucion;

	private Set<Desigualdad> desigualdades;
	private Configuracion configuracion;

	private Grafo g;
	private int colores;

	public Separator(Grafo g, int colores, SolucionFraccionaria solucion, Configuracion configuracion) {

		this.solucion = solucion;
		this.g = g;
		this.colores = colores;
		this.desigualdades = new HashSet<Desigualdad>();
		this.configuracion = configuracion;
	}

	public void separarCliquesExhaustivo() {

		int desClique = 0;

		int cliquesInspeccionadas = 0;
		long start = System.currentTimeMillis();
		
		for (int c = 0; c < colores; c++) {

			long check = System.currentTimeMillis();

			if (check - start > configuracion.maxMillisClique){
				GlobalStatistics.getInstance().cortesClique += desClique;			
				return;
			}
				
			if (cliquesInspeccionadas > configuracion.maxCliquesInspXColor)
				continue;

			// me quedo con las K clique más horribles.
			for (Set<Integer> clique : g.getCliques()) {

				if (clique.size() > 1) {

					DesigualdadClique dc = new DesigualdadClique(g, colores, c, clique);
					if (dc.violada(solucion)) {
						desigualdades.add(dc);
						desClique++;
					}

					cliquesInspeccionadas++;
				}
			}
		}

		GlobalStatistics.getInstance().cortesClique += desClique;

	}

	public void separar() {

		if (configuracion.conCortesClique){
			separarCliques();
			//separarCliquesExhaustivo();
		}
		separarRestantes();
	}

	public void separarCliques() {

		int desClique = 0;

		List<VariableX> variablesX = new ArrayList<VariableX>();
		Set<Integer> clique = new HashSet<Integer>();
		long start = System.currentTimeMillis();

		for (int c = 0; c < colores; c++) {
			
			variablesX.clear();
			for (int v = 0; v < g.getVertices(); v++) {

				if (solucion.getX(v, c) > configuracion.minXClique)
					variablesX.add(solucion.getVariableX(v, c));
			}

			// sort descending.
			Collections.sort(variablesX, new Comparator<VariableX>() {

				public int compare(VariableX o1, VariableX o2) {
					if (o1.valor < o2.valor)
						return 1;
					if (o1.valor == o2.valor)
						return 0;
					else
						return -1;
				}
			});

			for (int k = 0; k < this.configuracion.kIntentosDesClique; k++) {

				clique.clear();
				for (int kPrime = k; kPrime < variablesX.size(); kPrime++) {
					VariableX varX = variablesX.get(kPrime);
					int w = varX.v;

					if (g.getVecinos(w).containsAll(clique))
						clique.add(w);
				}

				// if (!g.esClique(clique))
				// throw new RuntimeException("No es una clique!");

				if (clique.size() > 1) {
					DesigualdadClique dc = new DesigualdadClique(g, colores, c, clique);
					if (dc.violada(solucion)) {
						desigualdades.add(dc);
						desClique++;
					}
				}
			}
			long check = System.currentTimeMillis();

			if (check - start > configuracion.maxMillisClique){
				GlobalStatistics.getInstance().cortesClique += desClique;			
				return;
			}
		}

		GlobalStatistics.getInstance().cortesClique += desClique;

	}

	public void separarRestantes() {

		List<VariableZ> variablesZ = new ArrayList<VariableZ>();

		for (int c = 0; c < colores; c++) {
			for (int v = 0; v < g.getVertices(); v++) {

				if (solucion.getZ(v, c) > configuracion.minZ)
					variablesZ.add(solucion.getVariableZ(v, c));
			}
		}

		// sort descending.
		Collections.sort(variablesZ, new Comparator<VariableZ>() {

			public int compare(VariableZ o1, VariableZ o2) {
				if (o1.valor < o2.valor)
					return 1;
				if (o1.valor == o2.valor)
					return 0;
				else
					return -1;
			}
		});

		int desTipo2 = 0;
		long start = System.currentTimeMillis();
		int contadorVariablesZ = 0;

		if (configuracion.conCortes2) {
			for (VariableZ varZ : variablesZ) {

				long check = System.currentTimeMillis();
				if (check - start > configuracion.maxMillisTipo2 || contadorVariablesZ >= configuracion.variablesZInspeccionadas)
					break;

				Set<Integer> aDistancia2 = g.aDistancia2(varZ.v);

				for (int w : aDistancia2) {

					for (int cPrime = 0; cPrime < colores; cPrime++) {

						if (solucion.getX(w, cPrime) > configuracion.minX && varZ.c != cPrime) {

							DesigualdadTipo2 d2 = new DesigualdadTipo2(g, varZ.v, varZ.c, w, cPrime, colores);
							if (d2.violada(solucion)) {
								desigualdades.add(d2);
								desTipo2++;
							}
						}
					}
				}

				contadorVariablesZ++;
			}
		}
		int desTipo3 = 0;
		int desTipo4 = 0;
		int desTipo5 = 0;

		start = System.currentTimeMillis();
		if (configuracion.conCortes3y4) {
			for (int i = 0; i < variablesZ.size(); i++)
				for (int j = i + 1; j < variablesZ.size(); j++) {

					long check = System.currentTimeMillis();
					if (check - start > configuracion.maxMillisTipo3)
						return;

					VariableZ varZi = variablesZ.get(i);
					VariableZ varZj = variablesZ.get(j);

					if (varZi.v != varZj.v && varZi.c == varZj.c) {

						if (g.vecindadIncluida(varZi.v, varZj.v)) {

							if (!g.isArista(varZi.v, varZj.v)) {
								DesigualdadTipo3 d3 = new DesigualdadTipo3(g, varZi.v, varZi.c, varZj.v, varZj.c, colores);
								if (d3.violada(solucion)) {
									desigualdades.add(d3);
									desTipo3++;
								}
							} else {

								DesigualdadTipo4 d4 = new DesigualdadTipo4(g, varZi.v, varZi.c, varZj.v, colores);
								if (d4.violada(solucion)) {
									desigualdades.add(d4);
									desTipo4++;
								}
							}

						}

						if (g.vecindadIncluida(varZj.v, varZi.v)) {
							if (!g.isArista(varZi.v, varZj.v)) {
								DesigualdadTipo3 d3 = new DesigualdadTipo3(g, varZj.v, varZj.c, varZi.v, varZi.c, colores);
								if (d3.violada(solucion)) {
									desigualdades.add(d3);
									desTipo3++;
								}
							} else {
								DesigualdadTipo4 d4 = new DesigualdadTipo4(g, varZj.v, varZj.c, varZi.v, colores);
								if (d4.violada(solucion)) {
									desigualdades.add(d4);
									desTipo4++;
								}
							}
						}
					}

				}
		}
		if (configuracion.conCortes5) {
			for (VariableZ varZ : variablesZ)
				if (varZ.valor > solucion.getX(varZ.v, varZ.c)) {
					DesigualdadTipo5 d5 = new DesigualdadTipo5(g, varZ.v, varZ.c, colores);
					if (d5.violada(solucion)) {
						desigualdades.add(d5);
						desTipo5++;
					}
				}
		}
		GlobalStatistics gs = GlobalStatistics.getInstance();
		gs.cortesTipo5 += desTipo5;
		gs.cortesTipo4 += desTipo4;
		gs.cortesTipo3 += desTipo3;
		gs.cortesTipo2 += desTipo2;

	}

	public Set<Desigualdad> getDesigualdades() {
		return desigualdades;
	}

}
