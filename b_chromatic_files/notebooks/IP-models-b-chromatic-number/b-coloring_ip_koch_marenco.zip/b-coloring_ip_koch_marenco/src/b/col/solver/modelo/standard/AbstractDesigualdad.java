package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

public abstract class AbstractDesigualdad implements Desigualdad {

	protected double rhs;
	protected int n;
	protected int colores;
	
	public AbstractDesigualdad(int n, int colores, double rhs){
		this.n = n;
		this.colores = colores;
		this.rhs = rhs;
	}

	public abstract double getCoeficienteX(int i, int c);

	public abstract double getCoeficienteZ(int i, int c);

	public abstract double getLHS(SolucionFraccionaria solucion);

	@Override
	public boolean violada(SolucionFraccionaria solucion) {
		return getLHS(solucion) - getRhs() > Configuracion.toleranciaViolClique;
	}

	public abstract IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException;

	@Override
	public double getRhs() {
		return rhs;
	}

	protected void checkRange(int i, int c) {
		if (i < 0 || i >= n || c < 0 || c > this.colores)			
			throw new IllegalArgumentException("Par vértice color inválido: (" + i + ", " + c + "), n = " + n + "c = " + this.colores);
	}

}
