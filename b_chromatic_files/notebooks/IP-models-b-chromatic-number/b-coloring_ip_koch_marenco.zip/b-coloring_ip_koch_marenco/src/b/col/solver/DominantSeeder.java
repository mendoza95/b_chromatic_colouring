package b.col.solver;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DominantSeeder {

	private int[] coloreo;
	private Grafo g;
	private int cantColores = 0;

	public DominantSeeder(Grafo g, int colores, int[] coloreo) {

		this.g = g;
		this.coloreo = Arrays.copyOf(coloreo, coloreo.length);
		this.cantColores = colores;
	}

	/***
	 * Siembra la mayor cantidad de dominantes que puede, en el grafo con el
	 * coloreo indicado.
	 * 
	 * @return
	 */
	public int seed() {

		int dominantesAgregados = 0;

		// tengo un conjunto de dominantes de distinto color.
		Set<Integer> coloresConDom = new HashSet<Integer>();
		Set<Integer> dominantes;
		if (cantColores == GraphColoringUtils.coloresUsados(coloreo))
			dominantes = GraphColoringUtils.verticesDominantes(g, coloreo);
		else 
			dominantes = new HashSet<Integer>();
		
		Set<Integer> candidatos = new HashSet<Integer>();

		// los que tienen grado suficiente, y están suficientemente lejos de los
		// demás dominantes son mis candidatos
		for (int v = 0; v < g.getVertices(); v++) {
			if (g.getGrado(v) >= cantColores - 1)
				candidatos.add(v);
		}

		// examino los candidatos, para ver si pueden convertirse en dominantes

		for (int v : candidatos) {
			int colorEnV = coloreo[v];
			if (!coloresConDom.contains(colorEnV)) {
				int[] coloreoCopia = Arrays.copyOf(coloreo, coloreo.length);
				if (convertirEnDominante(v, coloreoCopia, dominantes)) {
					dominantes.add(v);
					dominantesAgregados++;
					coloresConDom.add(colorEnV);
					aplicarCambios(coloreoCopia);
				}
			}
		}

		return dominantesAgregados;
	}

	
	private void aplicarCambios(int[] coloreo) {

		this.coloreo = coloreo;
	}

	// Si puede convertir a v en dominante, lo hace, modificando el coloreo
	// (en forma válida) de sus vecinos
	private boolean convertirEnDominante(int v, int[] coloreo, Set<Integer> dominantes) {

		Set<Integer> Nv = new HashSet<Integer>(g.getVecinos(v));
		Nv.removeAll(dominantes);
		Set<Integer> coloresFaltantes = GraphColoringUtils.coloresFaltantesEnNv(g, v, coloreo, cantColores);
		
		coloresFaltantes.remove(coloreo[v]);
		for (int w : Nv) {
			
			int cw = coloreo[w];
			// hay otro más en Nv de color de w?
			if (!GraphColoringUtils.esUnicoVecinoDeSuColor(g, v, w, coloreo)) {
				
				for (int c : coloresFaltantes) {
					//w admite algun color de los que faltan?
					boolean wAdmiteCol = true;
					Set<Integer> Nw = g.getVecinos(w);

					for (int w1 : Nw)
						if (coloreo[w1] == c)
							wAdmiteCol = false;

					if (wAdmiteCol) {
						// el nuevo color estropea algun dominante que ya
						// existe?
						for (int w1 : Nw)
							if (!dominantes.contains(w1) || !GraphColoringUtils.esUnicoVecinoDeSuColor(g, w1, w, coloreo)) {
								coloreo[w] = c;
								break;
							}
					}
				}
				// si recoloreamos a w
				if (cw != coloreo[w])
					// lo eliminamos de la lista de faltantes.
					coloresFaltantes.remove(coloreo[w]);

			}
		}
			return coloresFaltantes.isEmpty();		
	}

	//
	// private Set<Integer> dominantes(Set<Integer> coloresConDom) {
	//
	// // nos quedamos primero con los que tienen grado >= colores - 1
	// Map<Integer, Set<Integer>> gradosConVert = g.getGradosConVertices();
	// Set<Integer> dominantes = new HashSet<Integer>();
	//
	// for (int grado : gradosConVert.keySet()) {
	//
	// if (grado >= cantColores - 1) {
	// // este vértice podría ser dominante?
	// Set<Integer> vertConGrado = gradosConVert.get(grado);
	// for (int v : vertConGrado) {
	// // v es dominante
	// int colorDeV = coloreo[v];
	// if (colorDeV > -1 && !coloresConDom.contains(colorDeV) &&
	// GraphColoringUtils.dominante(g, v, coloreo, cantColores)) {
	// dominantes.add(v);
	// coloresConDom.add(colorDeV);
	// }
	// }
	// }
	// }
	// return dominantes;
	// }
	//
	public int[] getColoreo() {
		return coloreo;
	}

}
