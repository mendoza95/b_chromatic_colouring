package b.col.solver.modelo.standard;

public class Configuracion {

	public boolean conCortes1;
	public boolean conCortes2;
	public boolean conCortes3y4;
	public boolean conCortes5;
	public boolean conCortesClique;
	public int cortarCada = 200;
	public boolean conRestSimetria;
	public boolean graphReduction = false;
	public boolean initialSol = false;
	public static double toleranciaViolClique = 0;

	// configuracion para cortes clique
	public double minXClique = 0;
	public int kIntentosDesClique = 500; //20
	public long maxMillisClique = 10000;// 10000
	
	public long maxCliquesInspXColor = 200;
	

	// /configuracion para cortes tipo 2
	public int variablesZInspeccionadas = 400; // 200
	public long maxMillisTipo2 = 5000;// 10000
	public double minZ = 0.01;// 0.7
	public double minX = 0;// 0.2

	//configuracion para cortes tipo 3
	public long maxMillisTipo3 = 1000;// 10000

	public double timeLim = 60;
	public boolean conCuts;
	

	public boolean rInitialSol;
	public String rfileNameSol;
	public boolean rconCuts;
	
	@Override
	public String toString() {

		String res = "|CUTS " + conCuts;
		res += "|TIME " + timeLim;
		res += "|CT1 " + conCortes1;
		res += "|CT2 " + conCortes2;
		res += "|CT3 " + conCortes3y4;
		res += "|CT5 " + conCortes5;
		res += "|C CADA " + cortarCada;
		res += "|CTC " + conCortesClique;
		res += "|SIM " + conRestSimetria;
		res += "|RED " + graphReduction;

		return res;
	}
}
