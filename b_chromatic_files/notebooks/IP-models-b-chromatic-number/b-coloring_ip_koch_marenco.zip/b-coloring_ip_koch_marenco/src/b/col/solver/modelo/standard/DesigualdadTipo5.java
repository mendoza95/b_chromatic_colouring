package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import b.col.solver.Grafo;

public class DesigualdadTipo5 extends AbstractDesigualdad {

	// Cantidad de variables

	private int v;
	private int c;

	// Constructor
	public DesigualdadTipo5(Grafo g, int v, int c, int colores) {

		super(g.getVertices(), colores, 0);

		
		if (g.getGrado(v) < colores - 1)
			throw new RuntimeException("v no puede ser dominante");
			
		
		this.c = c;
		this.v = v;		
	}

	public double getCoeficienteX(int i, int c) {

		checkRange(i, c);

		if (i == this.v && c == this.c)
			return -1;
		else 
			return 0;
	}

	public double getCoeficienteZ(int i, int c) {

		checkRange(i, c);

		if (i == this.v && c == this.c)
			return 1;
		else 
			return 0;
	}

	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException {

		IloNumExpr cut = cplex.linearIntExpr();
		cut = cplex.sum(cut, cplex.prod(getCoeficienteZ(v, c), model.getZ()[v][c]));
		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, c), model.getX()[v][c]));

		return cplex.le(cut, this.rhs);
	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteZ(v, c) * solucion.getZ(v, c);
		_lhs += getCoeficienteX(v, c) * solucion.getX(v, c);
		
		return _lhs;
	}
}
