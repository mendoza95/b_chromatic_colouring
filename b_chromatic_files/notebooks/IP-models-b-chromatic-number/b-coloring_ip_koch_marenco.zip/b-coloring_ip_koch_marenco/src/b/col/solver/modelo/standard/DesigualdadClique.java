package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.Set;

import b.col.solver.Grafo;

public class DesigualdadClique extends AbstractDesigualdad {

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int c;
	private Set<Integer> K;

	// Constructor
	public DesigualdadClique(Grafo g, int colores, int c, Set<Integer> clique) {

		super(g.getVertices(), colores, 1);
		this.c = c;
		this.K = clique;

	}

	@Override
	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException {
		IloNumExpr cut = cplex.linearIntExpr();

		for (int v : K)
			cut = cplex.sum(cut, cplex.prod(this.getCoeficienteX(v, c), model.getX()[v][c]));

		return cplex.le(cut, this.rhs);
	}

	@Override
	public double getCoeficienteZ(int i, int c) {

		checkRange(i, c);

		return 0;
	}

	@Override
	public double getCoeficienteX(int i, int c) {

		checkRange(i, c);

		if (K.contains(i) && c == this.c)
			return 1;
		else
			return 0;

	}

	// Consulta el LHS en la solucion indicada
	@Override
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		for (int v : K)
			_lhs += getCoeficienteX(v, c) * solucion.getX(v, c);

		return _lhs;
	}

}
