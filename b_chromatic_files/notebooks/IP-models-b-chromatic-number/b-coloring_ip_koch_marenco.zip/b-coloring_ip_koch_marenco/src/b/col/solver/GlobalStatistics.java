package b.col.solver;

import ilog.cplex.IloCplex.CplexStatus;

public class GlobalStatistics {

	private static GlobalStatistics instance = new GlobalStatistics();

	public int cortesTipo1 = 0;
	public int cortesTipo2 = 0;
	public int cortesTipo3 = 0;
	public int cortesTipo4 = 0;
	public int cortesTipo5 = 0;
	public int cortesClique = 0;
	public long timeMillis = 0;
	public double gap = 0;
	public double mejorSolEntera = 0;
	public CplexStatus status;
	public double bestBound;
	public int nOriginal = 0;
	public int mOriginal = 0;
	public int nReducido = 0;
	public int mReducido = 0;

	private GlobalStatistics() {

	}

	public static GlobalStatistics getInstance() {

		return instance;
	}

	@Override
	public String toString() {

		String res = "";

		res += "|SE " + mejorSolEntera;
		res += "|BB " + bestBound;
		res += "|T " + timeMillis;
		res += "|G " + gap;
		res += "|S " + (status == null ? "" : status.toString());
		res += "|CT1 " + cortesTipo1;
		res += "|CT2 " + cortesTipo2;
		res += "|CT3 " + cortesTipo3;
		res += "|CT4 " + cortesTipo4;
		res += "|CT5 " + cortesTipo5;
		res += "|CTC " + cortesClique;
		res += "|n " + nOriginal;
		res += "|m " + mOriginal;
		res += "|n red " + nReducido;
		res += "|m red " + mReducido;

		return res;
	}

	public void clear() {
		this.cortesClique = 0;
		this.cortesTipo1 = 0;
		this.cortesTipo2 = 0;
		this.cortesTipo3 = 0;
		this.cortesTipo4 = 0;
		this.cortesTipo5 = 0;
		this.timeMillis = 0;
		this.gap = -1;
		this.mejorSolEntera = -1;
		this.bestBound = -1;
		this.status = CplexStatus.Unknown;
		this.nOriginal = 0;
		this.mOriginal = 0;
		this.nReducido = 0;
		this.mReducido = 0;

	}

}
