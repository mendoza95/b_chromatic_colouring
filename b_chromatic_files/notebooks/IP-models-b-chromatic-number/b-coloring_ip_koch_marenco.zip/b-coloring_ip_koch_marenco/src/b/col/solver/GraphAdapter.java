package b.col.solver;

import java.util.List;
import java.util.Set;

import org.jgrapht.Graphs;
import org.jgrapht.UndirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

import b.col.solver.Grafo.Arista;
import b.col.solver.Grafo.Builder;

public class GraphAdapter {

	/**
	 * Takes a graph in JGraphT format and converts it into a list of
	 * adjacencies.
	 * 
	 * @param graph
	 * @return
	 */
	public static Grafo convert(UndirectedGraph<Integer, DefaultEdge> graph) {

		int n = graph.vertexSet().size();

		
		Builder b = new Grafo.Builder(n);
		for (int j = 0; j < n; j++) {

			List<Integer> neighbours = Graphs.neighborListOf(graph, j);

			for (Integer v : neighbours)
				b.setArista(j, v);
		}

		return b.build();
	}

	/**
	 * Takes a graph in JGraphT format and converts it into a list of
	 * adjacencies.
	 * 
	 * @param graph
	 * @return
	 */
	public static UndirectedGraph<Integer, DefaultEdge> convert(Grafo g) {

		UndirectedGraph<Integer, DefaultEdge> graph = new SimpleGraph<Integer, DefaultEdge>(DefaultEdge.class);

		int n = g.getVertices();
		for (int j = 0; j < n; j++)
			graph.addVertex(j);

		Set<Arista> aristas = g.getAristas();
		for (Arista arista : aristas)
			graph.addEdge(arista.getI(), arista.getJ());

		return graph;
	}

}