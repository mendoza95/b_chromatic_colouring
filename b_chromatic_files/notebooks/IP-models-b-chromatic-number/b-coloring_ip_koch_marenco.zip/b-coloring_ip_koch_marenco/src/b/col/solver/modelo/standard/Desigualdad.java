package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

public interface Desigualdad {
	
	
	public double getCoeficienteX(int i, int c);
	public double getCoeficienteZ(int i, int c);
	public double getLHS(SolucionFraccionaria solucion);
	public boolean violada(SolucionFraccionaria solucion);
	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException;
	public double getRhs();

}
