package b.col.solver.modelo.representantes;

import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.alg.ConnectivityInspector;
import org.jgrapht.graph.DefaultEdge;

import b.col.solver.CPLEXInfoCallBack;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.Grafo.Arista;
import b.col.solver.GraphAdapter;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class BColModelRepresentatives {

	private IloNumVar[][] x;

	private boolean[][] validX;

	private Grafo g;
	private Configuracion configuracion;

	public BColModelRepresentatives(Grafo g) {

		this.g = g;
	}

	// Resuelve el problema entero
	public Solucion solve(Configuracion configuracion, OutputStream leftStream) throws Exception {

		this.configuracion = configuracion;
		testNonUniversalVertices(g);
		testConnected(g);
		int n = g.getVertices();
		// create CPLEX optimizer/modeler
		IloCplex cplex = new IloCplex();

		// build model
		IloNumVar[][][] var = new IloNumVar[1][][];

		IloRange[][] rng = new IloRange[1][];

		// variables x
		x = new IloNumVar[n][n];
		validX = new boolean[n][n];

		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				x[i][j] = cplex.boolVar();

		var[0] = x;

		// objective function
		IloNumExpr fobj = cplex.linearIntExpr();
		for (int i = 0; i < n; ++i) {
			fobj = cplex.sum(fobj, cplex.prod(1, x[i][i]));
			validX[i][i] = true;
		}

		cplex.addMaximize(fobj);

		// constraints
		ArrayList<IloRange> restricciones = new ArrayList<IloRange>();

		// x_uu + suma de colores en no vecinos es 1
		for (int u = 0; u < n; ++u) {

			IloNumExpr lhs = cplex.linearIntExpr();
			lhs = cplex.sum(lhs, cplex.prod(1.0, x[u][u]));
			for (int v = 0; v < n; v++)
				if (u != v && !g.isArista(v, u)) {
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[v][u]));
					validX[v][u] = true;
				}

			restricciones.add(cplex.addEq(lhs, 1, "R1:" + u));
		}

		// x_vu + x_wu <= x_uu si vw son aristas y ninguno de los dos son
		// vecinos de u.
		for (int u = 0; u < n; ++u) {
			Set<Arista> aristas = g.getAristas();
			for (Arista arista : aristas) {
				int v = arista.getI();
				int w = arista.getJ();

				if (u != v && u != w && !g.isArista(u, v) && !g.isArista(u, w)) {
					IloNumExpr lhs = cplex.linearIntExpr();
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[u][v]));
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[u][w]));
					lhs = cplex.sum(lhs, cplex.prod(-1.0, x[u][u]));
					validX[u][v] = true;
					validX[u][w] = true;
					restricciones.add(cplex.addLe(lhs, 0, "Ady" + arista));
				}
			}
		}

		// restriccion de dominancia
		for (int u = 0; u < n; ++u) {
			for (int v = 0; v < n; ++v) {

				if (u != v && !g.isArista(u, v)) {

					Set<Integer> Nu = g.getVecinos(u);

					IloNumExpr lhs = cplex.linearIntExpr();
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[u][u]));
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[v][v]));

					for (Integer w : Nu) {
						if (!g.isArista(w, v)) {
							lhs = cplex.sum(lhs, cplex.prod(-1.0, x[v][w]));
							validX[v][w] = true;
						}
					}
					restricciones.add(cplex.addLe(lhs, 1, "Dom" + u + "," + v));
				}
			}
		}

		rng[0] = new IloRange[restricciones.size()];

		int t = 0;
		for (IloRange range : restricciones)
			rng[0][t++] = range;

		if (configuracion.rconCuts) {
			CutGenerator generator = new CutGenerator(cplex, this);
			cplex.use(generator);
		}

		if (configuracion.rInitialSol) {
			Solucion solInicial = Solucion.loadFromTxt(g, configuracion.rfileNameSol);

			if (!solInicial.esBColoreo())
				throw new RuntimeException("Sol inicial no es b coloreo");

			Set<Integer> dominantes = solInicial.getDominantes();
			int[] coloreo = solInicial.getColoreo();

			// dado un color, qué vertice lo representa.
			Map<Integer, Integer> representantes = new HashMap<Integer, Integer>();

			Set<IloNumVar> vars = new HashSet<IloNumVar>();
			for (int u = 0; u < n; ++u)
				for (int v = 0; v < n; ++v)
					if (validX[u][v])
						vars.add(x[u][v]);

			for (int v : dominantes)
				representantes.put(coloreo[v], v);

			IloNumVar[] startVar = new IloNumVar[vars.size()];
			double[] startVal = new double[vars.size()];

			int indice = 0;

			for (int v = 0; v < g.getVertices(); v++) {
				for (int w = 0; w < g.getVertices(); w++) {

					if (validX[v][w]) {
						startVar[indice] = x[v][w];

						int representante = representantes.get(coloreo[w]);
						if (v == representante)
							startVal[indice] = 1;

						indice++;
					}

				}
			}
			cplex.addMIPStart(startVar, startVal);
			startVar = null;
			startVal = null;
		}

		CPLEXInfoCallBack infocallback = new CPLEXInfoCallBack();
		cplex.use(infocallback);

		cplex.setOut(leftStream);

		cplex.setParam(IloCplex.DoubleParam.TiLim, configuracion.timeLim);
		cplex.setParam(IloCplex.IntParam.AdvInd, 1);
		// optimize and output solution information
		long start = System.currentTimeMillis();
		boolean ok = cplex.solve();
		long end = System.currentTimeMillis();

		GlobalStatistics stat = GlobalStatistics.getInstance();
		stat.timeMillis = (end - start);
		System.out.print(leftStream.toString());

		stat.gap = cplex.getMIPRelativeGap();
		stat.mejorSolEntera = cplex.getObjValue();
		stat.status = cplex.getCplexStatus();

		stat.bestBound = cplex.getBestObjValue();

		// optimize and output solution information
		System.out.print(leftStream.toString());

		if (ok) {

			Set<Integer> dominantes = new HashSet<Integer>();
			Map<Integer, Integer> vertColor = new HashMap<Integer, Integer>();

			int color = 0;
			for (int v = 0; v < n; v++)
				if (cplex.getValue(x[v][v]) > 0) {
					dominantes.add(v);
					vertColor.put(v, color++);
				}

			int colores = (int) Math.round(cplex.getBestObjValue());
			Solucion sol = new Solucion(g, colores, colores, dominantes);
			for (int u : dominantes)
				for (int v = 0; v < n; v++) {
					if (validX[u][v] && cplex.getValue(x[u][v]) > 0)
						sol.setColor(v, vertColor.get(u));
				}

			return sol;
		} else
			return null;
	}

	private void testNonUniversalVertices(Grafo g) {

		int n = g.getVertices();
		for (int v = 0; v < n; v++)
			if (g.getGrado(v) == n - 1)
				throw new RuntimeException("El grafo no debe contener vertices universales");
	}

	private void testConnected(Grafo g) {

		ConnectivityInspector<Integer, DefaultEdge> ci = new ConnectivityInspector<Integer, DefaultEdge>(GraphAdapter.convert(g));
		if (!ci.isGraphConnected())
			throw new RuntimeException("El grafo no es conexo");
	}

	public IloNumVar[][] getX() {
		return x;
	}

	public Grafo getG() {
		return g;
	}

	public boolean[][] getValidX() {
		return validX;
	}

	public Configuracion getConfiguracion() {
		return configuracion;
	}

}
