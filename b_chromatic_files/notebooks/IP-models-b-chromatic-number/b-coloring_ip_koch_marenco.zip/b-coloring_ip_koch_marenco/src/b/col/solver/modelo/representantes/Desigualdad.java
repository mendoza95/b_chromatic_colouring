package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

public interface Desigualdad {
	
	
	public double getCoeficienteX(int i, int c);	
	public double getLHS(SolucionFraccionaria solucion);
	public boolean violada(SolucionFraccionaria solucion);
	public IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException;
	public double getRhs();

}
