package b.col.solver.modelo.representantes;

import b.col.solver.Grafo;
import ilog.concert.IloException;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

public abstract class AbstractDesigualdad implements Desigualdad {

	protected double rhs;
	protected Grafo g;
	protected int n;

	public AbstractDesigualdad(Grafo g, double rhs) {
		this.n = g.getVertices();
		this.g = g;
		this.rhs = rhs;
	}

	public abstract double getCoeficienteX(int i, int c);

	public abstract double getLHS(SolucionFraccionaria solucion);

	@Override
	public boolean violada(SolucionFraccionaria solucion) {
		return getLHS(solucion) > getRhs();
	}

	public abstract IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException;

	@Override
	public double getRhs() {
		return rhs;
	}

	protected void checkRange(int i) {
		if (i < 0 || i >= n)
			throw new IllegalArgumentException("vértice inválido: " + i + ", n = " + n);
	}

}
