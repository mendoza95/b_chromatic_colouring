package b.col.solver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.jgrapht.UndirectedGraph;
import org.jgrapht.alg.BronKerboschCliqueFinder;
import org.jgrapht.alg.ConnectivityInspector;
import org.jgrapht.alg.FloydWarshallShortestPaths;
import org.jgrapht.graph.DefaultEdge;

public class Grafo {

	public class Arista {
		private int i;
		private int j;

		public Arista(int i, int j) {
			this.i = i;
			this.j = j;
		}

		public int getI() {
			return i;
		}

		public void setI(int i) {
			this.i = i;
		}

		public int getJ() {
			return j;
		}

		public void setJ(int j) {
			this.j = j;
		}

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "(" + i + "," + j + ")";
		}
	}

	// Cantidad de aristas
	private int n;

	// Aristas
	private boolean[][] aristas;

	private Map<Integer, Set<Integer>> verticesADistancia2;

	private double[][] distancias;

	private boolean[][] gradoIncluido;

	private int[] grados;

	private Map<Integer, Set<Integer>> vecinos;

	private Set<Arista> setAristas;

	private int gradoMaximo = -1;

	private List<Integer> vertOrdDesc;

	private Map<Integer, Set<Integer>> gradosConVertices;

	private int[][] cantNoAristas;

	private Collection<Set<Integer>> cliques;

	public static class Builder {

		private boolean[][] aristas;
		private int n;

		public Builder(int n) {
			this.n = n;
			aristas = new boolean[n][n];
		}

		public Builder setArista(int i, int j) {
			aristas[i][j] = true;
			aristas[j][i] = true;
			return this;
		}

		public boolean isArista(int i, int j) {
			return aristas[i][j];
		}

		public int getN() {
			return n;
		}

		public Grafo build() {
			return new Grafo(this);
		}
	}

	// Constructor
	private Grafo(Builder b) {

		this.n = b.getN();
		this.aristas = new boolean[n][n];
		this.gradoIncluido = new boolean[n][n];
		this.cantNoAristas = new int[n][n];
		this.grados = new int[n];
		this.vecinos = new HashMap<Integer, Set<Integer>>();
		this.setAristas = new HashSet<Grafo.Arista>();

		for (int i = 0; i < n; ++i)
			for (int j = i + 1; j < n; ++j)
				if (b.isArista(i, j))
					this.setArista(i, j);

		preprocess();

		for (int v = 0; v < n; ++v)
			for (int w = v + 1; w < n; ++w)
				if (!this.isArista(v, w)) {
					Set<Integer> Nv = this.getVecinos(v);
					Set<Integer> Nw = this.getVecinos(w);

					for (int vecV : Nv)
						for (int vecW : Nw) {
							this.cantNoAristas[vecV][vecW]++;
							this.cantNoAristas[vecW][vecV]++;
						}
				}

	}

	// Grado de un vertice
	public int getGrado(int i) {

		return grados[i];
	}

	public int getCantidadNoAristas(int i, int j) {

		checkRange(i, j);
		return cantNoAristas[i][j];

	}

	public Set<Arista> getAristas() {

		return Collections.unmodifiableSet(setAristas);
	}

	// Conjunto de vecinos de un vertice, y vecinos comunes de dos vertices
	public Set<Integer> getVecinos(int i) {

		return Collections.unmodifiableSet(this.vecinos.get(i));
	}

	public boolean isArista(int i, int j) {
		checkRange(i, j);

		return aristas[i][j];
	}

	private void preprocess() {
		calcularGrados();
		calcularAristas();
		calcularVecinos();
		calcularGradosConVertices();
		calcularGradoIncluido();
		calcularDistancia2();
		//calcularCliques();
		// calcularDistancias();
		//System.out.println("Fin preproceso grafo. Cliques " + this.cliques.size());
	}

	private void calcularCliques() {

		BronKerboschCliqueFinder<Integer, DefaultEdge> cliqueFinder = new BronKerboschCliqueFinder<Integer, DefaultEdge>(GraphAdapter.convert(this));

		this.cliques = cliqueFinder.getAllMaximalCliques();//getAllMaximalCliques();
	}

	private void calcularDistancias() {

		FloydWarshallShortestPaths<Integer, DefaultEdge> fwshp = new FloydWarshallShortestPaths<>(GraphAdapter.convert(this));

		distancias = new double[n][n];
		for (int i = 0; i < n; ++i)
			for (int j = i + i; j < n; ++j) {
				distancias[i][j] = fwshp.shortestDistance(i, j);
				distancias[j][i] = distancias[i][j];
			}
	}

	private void calcularDistancia2() {

		verticesADistancia2 = new HashMap<Integer, Set<Integer>>();

		for (int i = 0; i < n; ++i)
			verticesADistancia2.put(i, new HashSet<Integer>());

		for (int i = 0; i < n; ++i)
			for (int j = i + 1; j < n; ++j) {
				if (!isArista(i, j)) {
					boolean aDist2 = false;
					Set<Integer> Ni = getVecinos(i);
					for (int w : Ni)
						if (isArista(w, j))
							aDist2 = true;

					if (aDist2) {
						verticesADistancia2.get(i).add(j);
						verticesADistancia2.get(j).add(i);
					}
				}
			}
	}

	public Set<Integer> aDistancia2(int i) {

		return Collections.unmodifiableSet(verticesADistancia2.get(i));
	}

	public double getDistancia(int i, int j) {

		checkRange(i, j);

		return distancias[i][j];
	}

	public boolean vecindadIncluida(int i, int j) {

		checkRange(i, j);

		return gradoIncluido[i][j];
	}

	public Map<Integer, Set<Integer>> getGradosConVertices() {

		return Collections.unmodifiableMap(gradosConVertices);
	}

	public List<Integer> verticesPorGradoDescendente() {

		if (vertOrdDesc == null) {

			vertOrdDesc = new ArrayList<Integer>();

			// las devuelve en orden descendente
			for (int grado : gradosConVertices.keySet()) {
				vertOrdDesc.addAll(gradosConVertices.get(grado));
			}
		}
		return Collections.unmodifiableList(vertOrdDesc);
	}

	// Agrega una arista
	private void setArista(int i, int j) {

		checkRange(i, j);

		aristas[i][j] = true;
		aristas[j][i] = true;
	}

	/**
	 * String representation of the graph.
	 * 
	 * @param graph
	 * @return
	 */

	public String toStringDeMierda() {

		StringBuilder sb = new StringBuilder();

		sb.append("n = " + this.getVertices() + ";\n");

		sb.append("Edges = {");
		boolean first = true;
		for (int i = 0; i < this.getVertices(); ++i)
			for (int j = i + 1; j < this.getVertices(); ++j)
				if (this.isArista(i, j))
					if (first) {
						sb.append("<" + (i + 1) + ", " + (j + 1) + ">");
						first = false;
					} else
						sb.append(", <" + (i + 1) + ", " + (j + 1) + ">");
		sb.append("};");
		return sb.toString();
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();

		sb.append(this.getVertices() + "\n");

		for (int i = 0; i < this.getVertices(); ++i)
			for (int j = i + 1; j < this.getVertices(); ++j)
				if (this.isArista(i, j))
					sb.append(i + ", " + j + "\n");

		return sb.toString();
	}

	public int getGradoMaximo() {

		if (gradoMaximo == -1) {
			gradoMaximo = 0;
			for (int v = 0; v < n; v++)
				gradoMaximo = Math.max(this.getGrado(v), gradoMaximo);
		}

		return gradoMaximo;
	}

	public Grafo getSubgrafo(Set<Integer> vertices) {

		Builder b = new Builder(vertices.size());

		// renombramos los vértices, desde 0, correlativos
		Map<Integer, Integer> vertNuevos = new HashMap<Integer, Integer>();

		int w = 0;
		for (int v : vertices)
			vertNuevos.put(v, w++);

		for (int v1 : vertices)
			for (int v2 : vertices)
				if (v1 != v2 && this.isArista(v1, v2))
					b.setArista(vertNuevos.get(v1), vertNuevos.get(v2));

		return b.build();

	}

	public List<Set<Integer>> componentesConexas() {

		UndirectedGraph<Integer, DefaultEdge> g = GraphAdapter.convert(this);
		ConnectivityInspector<Integer, DefaultEdge> ci = new ConnectivityInspector<Integer, DefaultEdge>(g);

		return ci.connectedSets();

	}

	// public void complementar() {
	// for (int i = 0; i < n; ++i)
	// for (int j = 0; j < n; ++j)
	// if (i != j)
	// aristas[i][j] = !aristas[i][j];
	// }

	// Consultas
	public int getVertices() {
		return n;
	}

	private void calcularGradoIncluido() {
		for (int v = 0; v < n; v++)
			for (int w = 0; w < n; w++)
				if (v != w && this.vecinos.get(v).containsAll(this.vecinos.get(w)))
					this.gradoIncluido[v][w] = true;
	}

	private void calcularGrados() {

		for (int v = 0; v < n; v++) {
			grados[v] = 0;
			for (int j = 0; j < n; ++j)
				if (v != j && isArista(v, j))
					++grados[v];
		}
	}

	private void calcularAristas() {

		setAristas.clear();
		for (int v = 0; v < this.getVertices(); ++v)
			for (int w = v + 1; w < this.getVertices(); ++w)
				if (this.isArista(v, w))
					setAristas.add(new Arista(v, w));
	}

	private void calcularVecinos() {

		for (int v = 0; v < this.getVertices(); ++v) {

			Set<Integer> ret = new HashSet<Integer>();
			for (int j = 0; j < n; ++j)
				if (v != j && isArista(v, j))
					ret.add(j);
			this.vecinos.put(v, ret);
		}

	}

	private void calcularGradosConVertices() {
		// el orden que usamos es el orden descendente de los enteros.
		gradosConVertices = new TreeMap<Integer, Set<Integer>>(new Comparator<Integer>() {

			public int compare(Integer o1, Integer o2) {
				return o2.compareTo(o1);
			}
		});

		for (int v = 0; v < n; v++) {

			int grado = this.getGrado(v);

			if (gradosConVertices.containsKey(grado)) {
				Set<Integer> vertConGrado = gradosConVertices.get(grado);
				vertConGrado.add(v);
			} else {
				Set<Integer> vertConGrado = new HashSet<Integer>();
				vertConGrado.add(v);
				gradosConVertices.put(grado, vertConGrado);
			}
		}
	}

	private void checkRange(int i, int j) {
		if (i < 0 || i >= n || j < 0 || j >= n || i == j)
			throw new IllegalArgumentException("Par de vértices inválido: (" + i + ", " + j + "), n = " + n);
	}

	public Collection<Set<Integer>> getCliques() {
		return cliques;
	}
	
	public boolean esClique (Set<Integer> vertices) {
		
		for (int v: vertices)
			for (int w: vertices)
				if (v != w && !isArista(v, w))
						return false;
			
		return true;
	}

}
