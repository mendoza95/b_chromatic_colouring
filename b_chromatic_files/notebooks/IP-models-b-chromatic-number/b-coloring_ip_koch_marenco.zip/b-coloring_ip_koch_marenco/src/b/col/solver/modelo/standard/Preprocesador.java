package b.col.solver.modelo.standard;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.DominantSeeder;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;

public class Preprocesador {

	public static Grafo grafoReducido(Grafo grafoOriginal, int colores) {

		Set<Integer> candADominante = new HashSet<Integer>();

		for (int v = 0; v < grafoOriginal.getVertices(); v++)
			if (grafoOriginal.getGrado(v) >= colores - 1)
				candADominante.add(v);

		Set<Integer> subgrafo = new HashSet<Integer>();

		subgrafo.addAll(candADominante);

		for (int w : candADominante)
			subgrafo.addAll(grafoOriginal.getVecinos(w));

		return grafoOriginal.getSubgrafo(subgrafo);

	}

	public static int[] solucionInicialMejorada(Grafo g, int colores) {

		DSATUR dsatur = new DSATUR(g);
		int[] coloreo = dsatur.color();

		//int colDom = GraphColoringUtils.coloresDominantes(g, coloreo).size();

		DominantSeeder ds = new DominantSeeder(g, colores, coloreo);

		ds.seed();

		int[] nuevoColoreo = ds.getColoreo();
		//int coloresDom = GraphColoringUtils.coloresDominantes(g, nuevoColoreo).size();

//		int[] mejorColoreo = null;
//		if (coloresDom > colDom)
//			mejorColoreo = nuevoColoreo;
//		else
//			mejorColoreo = coloreo;
		
		//asegurarCantidadColores(g, mejorColoreo, colores);
		return nuevoColoreo;

	}

	public static void asegurarCantidadColores(Grafo g, int[] coloreo, int colores) {

		int coloresUsados = GraphColoringUtils.coloresUsados(coloreo);
		if (coloresUsados < colores) {

			for (int v = 0; v < g.getVertices(); v++) {

				if (g.getGrado(v) >= colores - 1) {
					Set<Integer> Nw = g.getVecinos(v);
					int nuevoColor = coloresUsados;
					for (int w : Nw) {
						coloreo[w] = nuevoColor;
						nuevoColor++;
						if (nuevoColor == colores)
							return;
					}

				}

			}
		}
	}

	public static int[] solucionInicial(Grafo g, int colores) {

		DSATUR dsatur = new DSATUR(g);
		int[] solucion = dsatur.color();

		// si la solución de DSATUR usa menos colores, agregamos colores y de
		// paso creamos al menos un dominante.
		int coloresUsados = GraphColoringUtils.coloresUsados(solucion);

		if (coloresUsados < colores) {
			int nuevoActual = coloresUsados;
			int w = g.verticesPorGradoDescendente().get(0);

			boolean[] colorYaUsadoEnNw = new boolean[colores];
			Set<Integer> Nw = g.getVecinos(w);

			Iterator<Integer> it = Nw.iterator();

			while (it.hasNext() && nuevoActual < colores) {
				int v = it.next();
				// es el segundo vértice coloreado con solucion[v]
				if (colorYaUsadoEnNw[solucion[v]])
					solucion[v] = nuevoActual++;
				else
					colorYaUsadoEnNw[solucion[v]] = true;
			}

		}

		return solucion;
	}

}
