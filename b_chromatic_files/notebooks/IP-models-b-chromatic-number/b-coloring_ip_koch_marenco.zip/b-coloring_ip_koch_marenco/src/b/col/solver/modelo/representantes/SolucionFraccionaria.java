package b.col.solver.modelo.representantes;

import b.col.solver.Grafo;

public class SolucionFraccionaria {
	// Cantidad de v�rtices

	private int n;

	// Valores de las variables
	private double[][] x;
	

	// Constructor
	public SolucionFraccionaria(Grafo g) {
		this.n = g.getVertices();
		x = new double[n][n];		
	}

	public void setX(int i, int j, double valor) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		x[i][j] = valor;
	}

	// Getters para variables
	public double getX(int i, int j) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		return x[i][j];
	}
}
