package b.col.solver.modelo.standard;

import b.col.solver.Grafo;

public class SolucionFraccionaria {
	// Cantidad de v�rtices

	private int n;

	// Valores de las variables
	private double[][] x;
	private double[][] z;

	// Constructor
	public SolucionFraccionaria(Grafo g, int colores) {
		this.n = g.getVertices();
		x = new double[n][colores];
		z = new double[n][colores];
	}

	public void setX(int i, int j, double valor) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		x[i][j] = valor;
	}

	// Getters para variables
	public double getX(int i, int j) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		return x[i][j];
	}

	public void setZ(int i, int j, double valor) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		z[i][j] = valor;
	}

	// Getters para variables
	public double getZ(int i, int j) {
		if (i < 0 || i >= n || j < 0 || j >= n)
			throw new IllegalArgumentException();

		return z[i][j];
	}

	public VariableZ getVariableZ(int i, int j) {
		return new VariableZ(i, j, z[i][j]);

	}

	public VariableX getVariableX(int i, int j) {
		return new VariableX(i, j, x[i][j]);

	}

	public class VariableZ  {

		public int v;
		public int c;
		public double valor;

		public VariableZ(int v, int c, double valor) {
			this.v = v;
			this.c = c;
			this.valor = valor;
		}		
	}

	public class VariableX {

		public int v;
		public int c;
		public double valor;

		public VariableX(int v, int c, double valor) {
			this.v = v;
			this.c = c;
			this.valor = valor;
		}

	}
}
