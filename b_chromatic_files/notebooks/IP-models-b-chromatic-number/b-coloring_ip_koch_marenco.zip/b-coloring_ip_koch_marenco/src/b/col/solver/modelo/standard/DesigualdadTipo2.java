package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.HashSet;
import java.util.Set;

import b.col.solver.Grafo;

public class DesigualdadTipo2 extends AbstractDesigualdad {

	// Cantidad de variables

	private int v;
	private int c;
	private int u;
	private int cPrime;
	private Set<Integer> NvMinusW;

	// Constructor
	public DesigualdadTipo2(Grafo g, int v, int c, int u, int cPrime, int colores) {

		super(g.getVertices(), colores, 1);
		if (g.isArista(v, u))
			throw new RuntimeException("v y u son adyacentes!");

		if (c == cPrime)
			throw new RuntimeException("c y cPrima son iguales!");

		if (g.getGrado(v) < colores - 1 )
			throw new RuntimeException("v no puede ser dominante");
		
		this.c = c;
		this.v = v;
		this.u = u;
		this.NvMinusW = new HashSet<Integer>(g.getVecinos(v));
		this.NvMinusW.removeAll(g.getVecinos(u));

	}

	public double getCoeficienteX(int i, int c) {

		checkRange(i, c);

		if (i == this.u)
			if (c == this.cPrime)
				return 1;
			else
				return 0;

		if (c != this.cPrime)
			return 0;
		else if (!NvMinusW.contains(i))
			return 0;
		else
			return -1;
	}

	public double getCoeficienteZ(int i, int c) {

		checkRange(i, c);

		if (i == this.v && c == this.c)
			return 1;
		else
			return 0;
	}

	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException {
		IloNumExpr cut = cplex.linearIntExpr();
		cut = cplex.sum(cut, cplex.prod(getCoeficienteZ(v, c), model.getZ()[v][c]));
		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(u, cPrime), model.getX()[u][cPrime]));

		for (int w : this.NvMinusW)
			cut = cplex.sum(cut, cplex.prod(this.getCoeficienteX(w, cPrime), model.getX()[w][cPrime]));

		return cplex.le(cut, this.rhs);
	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteZ(v, c) * solucion.getZ(v, c);
		_lhs += getCoeficienteX(u, cPrime) * solucion.getX(u, cPrime);

		for (int w : this.NvMinusW)
			_lhs += getCoeficienteX(w, cPrime) * solucion.getX(w, cPrime);

		return _lhs;
	}

}
