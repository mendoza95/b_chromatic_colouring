package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.Set;

import b.col.solver.Grafo;
import b.col.solver.modelo.representantes.SolucionFraccionaria;

public class DesigualdadClique extends AbstractDesigualdad {

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int v;
	private Set<Integer> K;

	// Constructor
	public DesigualdadClique(Grafo g, int v, Set<Integer> K) {

		super(g, 0);
		this.v = v;
		this.K = K;
		
		if (K.contains(v))
			throw new RuntimeException("v está contenido en K");
	}

	public IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException {
		IloNumExpr cut = cplex.linearIntExpr();

		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, v), model.getX()[v][v]));

		for (int u : K)
			if (model.getValidX()[v][u])
				cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, u), model.getX()[v][u]));

		return cplex.le(cut, this.rhs);
	}

	public double getCoeficienteX(int i, int j) {

		checkRange(i);
		checkRange(j);

		if (i == v)
			if (j == v)
				return -1;
			else 
				if (K.contains(j))
					return 1;
				else 
					return 0;					
		else
			return 0;

	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteX(v, v) * solucion.getX(v, v);

		for (int u : K)
			_lhs += getCoeficienteX(v, u) * solucion.getX(v, u);

		return _lhs;
	}
}
