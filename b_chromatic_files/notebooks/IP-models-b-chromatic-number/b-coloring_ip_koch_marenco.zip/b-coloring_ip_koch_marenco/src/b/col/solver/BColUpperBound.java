package b.col.solver;

import java.util.List;

public class BColUpperBound {
	
	
	public static int upperBound(Grafo g){
		
		List<Integer> verticesPorGradoDesc = g.verticesPorGradoDescendente();
		
		int i = 1;
		
		while (i <= g.getVertices() && g.getGrado(verticesPorGradoDesc.get(i-1)) >= i - 1)
			i++;

		return i - 1;
	}

}
