package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import b.col.solver.Grafo;

public class DesigualdadTipo3 extends AbstractDesigualdad {

	// Cantidad de variables

	private int v;
	private int c;
	private int u;
	private int cPrime;

	// Constructor
	public DesigualdadTipo3(Grafo g, int v, int c, int u, int cPrime, int colores) {

		super(g.getVertices(), colores, 1);

		if (g.isArista(v, u))
			throw new RuntimeException("v y u son adyacentes!");

		if (c == cPrime)
			throw new RuntimeException("c y cPrima son iguales!");

		if (!g.vecindadIncluida(v, u))
			throw new RuntimeException("La vecindad de v no está incluida en la de u!");
		
		if (g.getGrado(v) < colores - 1)
			throw new RuntimeException("v no puede ser dominante");
		
		if (g.getGrado(u) < colores - 1)
			throw new RuntimeException("u no puede ser dominante");

		this.c = c;
		this.v = v;
		this.u = u;
		this.cPrime = cPrime;
	}

	public double getCoeficienteX(int i, int c) {

		checkRange(i, c);

		return 0;
	}

	public double getCoeficienteZ(int i, int c) {

		checkRange(i, c);

		if ((i == this.v && c == this.c) || (i == this.u && c == this.cPrime))
			return 1;
		else
			return 0;
	}

	public IloRange buildCut(IloCplex cplex, BColModelStandard model) throws IloException {

		IloNumExpr cut = cplex.linearIntExpr();
		cut = cplex.sum(cut, cplex.prod(getCoeficienteZ(v, c), model.getZ()[v][c]));
		cut = cplex.sum(cut, cplex.prod(getCoeficienteZ(u, cPrime), model.getZ()[u][cPrime]));

		return cplex.le(cut, this.rhs);
	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;

		_lhs += getCoeficienteZ(v, c) * solucion.getZ(v, c);
		_lhs += getCoeficienteZ(u, cPrime) * solucion.getZ(u, cPrime);

		return _lhs;
	}
}
