package b.col.solver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class GraphColoringUtils {

	public static boolean esColoreo(Grafo g, int[] coloreo) {

		for (int v = 0; v < g.getVertices(); v++)
			for (int w : g.getVecinos(v))
				if (coloreo[v] == coloreo[w]) {
					System.out.println("Coloreo no valido." + v + "=" + coloreo[v] + " " + w + "=" + coloreo[w]);
					return false;

				}

		return true;
	}

	public static int coloresUsados(int[] coloreo) {

		int max = -1;
		for (int i = 0; i < coloreo.length; i++)
			max = Math.max(max, coloreo[i]);

		return max + 1;
	}

	public static Set<Integer> coloresUsadosEnNv(Grafo g, int v, int[] coloreo) {

		Set<Integer> cols = new HashSet<Integer>();
		for (int w : g.getVecinos(v))
			if (coloreo[w] > -1)
				cols.add(coloreo[w]);
		return cols;
	}

	public static Set<Integer> coloresFaltantesEnNv(Grafo g, int v, int[] coloreo, int cantColores) {

		Set<Integer> cols = coloresUsadosEnNv(g, v, coloreo);
		Set<Integer> colsFalt = new HashSet<Integer>();

		for (int c = 0; c < cantColores; c++)
			if (!cols.contains(c))
				colsFalt.add(c);

		return colsFalt;
	}

	public static boolean dominante(Grafo g, int v, int[] coloreo) {

		int coloresUsados = GraphColoringUtils.coloresUsados(coloreo);
		Set<Integer> cols = new HashSet<Integer>();

		for (int w : g.getVecinos(v))
			if (coloreo[w] > -1)
				cols.add(coloreo[w]);

		return cols.size() == coloresUsados - 1;
	}

	public static boolean esUnicoVecinoDeSuColor(Grafo g, int v, int w, int[] coloreo) {

		int c = coloreo[w];

		for (int w1 : g.getVecinos(v))
			if (coloreo[w1] == coloreo[w])
				return false;

		return true;
	}

	public static Set<Integer> verticesDominantes(Grafo g, int[] coloreo) {

		Set<Integer> vertDom = new HashSet<Integer>();

		for (int v = 0; v < g.getVertices(); v++)

			if (dominante(g, v, coloreo))
				vertDom.add(v);

		return vertDom;
	}

	public static Set<Integer> coloresDominantes(Grafo g, int[] coloreo) {

		Set<Integer> resultado = new HashSet<Integer>();
		for (int v = 0; v < g.getVertices(); v++)
			if (GraphColoringUtils.dominante(g, v, coloreo))
				resultado.add(coloreo[v]);

		return resultado;
	}

	public static Map<String, int[]> uploadBounds(String fileName) throws FileNotFoundException {

		Map<String, int[]> res = new HashMap<String, int[]>();

		FileInputStream fis = new FileInputStream(fileName);
		Scanner scanner = new Scanner(fis);
		try {

			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();

				if (linea.isEmpty())
					continue;

				String[] tokens = linea.split(" ");

				int[] bounds = new int[3];
				bounds[0] = Integer.parseInt(tokens[1]);
				bounds[1] = Integer.parseInt(tokens[2]);
				bounds[2] = Integer.parseInt(tokens[3]);

				res.put(tokens[0], bounds);

			}
		} finally {
			scanner.close();
		}

		return res;

	}
}
