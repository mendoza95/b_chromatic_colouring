package b.col.solver.modelo.standard;

import ilog.concert.IloException;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;

import java.util.Arrays;

import b.col.solver.DSATUR;
import b.col.solver.GraphColoringUtils;

public class DSATURHeuristicCallback extends IloCplex.HeuristicCallback {

	private BColModelStandard model;
	private int activacion = 0;

	private static final double MAXTOL = 0.3;

	public DSATURHeuristicCallback(BColModelStandard model) {
		this.model = model;
	}

	@Override
	public void main() throws IloException {

		if (activacion % 10 == 0) {

			System.err.println("Procedimiento de agregado de solución heurística " + activacion);
			int[] precoloreo = buildPrecoloring();

			DSATUR dsatur = new DSATUR(model.getG(), precoloreo, model.getColores());

			int[] resultado = dsatur.color();

			inyectarEnModelo(resultado);
		}

		activacion++;
	}

	/**
	 * Nos quedamos con las variables que valen 1, menos alguna tolerancia
	 * 
	 * @return
	 * @throws IloException
	 */
	private int[] buildPrecoloring() throws IloException {

		int n = model.getG().getVertices();
		int colores = model.getColores();

		int[] precoloreo = new int[n];

		Arrays.fill(precoloreo, -1);

		for (int v = 0; v < n; v++)
			for (int color = 0; color < colores; color++)
				if (getValue(model.getX()[v][color]) >= 1 - DSATURHeuristicCallback.MAXTOL)
					precoloreo[v] = color;

		return precoloreo;
	}

	private void inyectarEnModelo(int[] coloreo) throws IloException {

		int n = model.getG().getVertices();
		int colores = model.getColores();

		IloNumVar[] variables = new IloNumVar[2 * n * colores + colores];
		double[] valores = new double[2 * n * colores + colores];

		int indiceVariable = 0;

		for (int v = 0; v < n; v++)
			for (int color = 0; color < colores; color++)
				variables[indiceVariable++] = model.getX()[v][color];

		for (int v = 0; v < n; v++)
			for (int color = 0; color < colores; color++)
				variables[indiceVariable++] = model.getZ()[v][color];

		for (int color = 0; color < colores; color++)
			variables[indiceVariable++] = model.getD()[color];

		indiceVariable = 0;

		// valores para las x
		for (int v = 0; v < n; v++)
			for (int color = 0; color < colores; color++)
				if (coloreo[v] == color)
					valores[indiceVariable++] = 1;
				else
					valores[indiceVariable++] = 0;

		int[] valoresD = new int[colores];

		// valores para las z
		for (int v = 0; v < n; v++) {
			boolean dominante = GraphColoringUtils.dominante(model.getG(), v, coloreo);
			for (int color = 0; color < colores; color++)
				if (coloreo[v] == color && dominante) {
					valores[indiceVariable++] = 1;
					valoresD[color] = 1;
				} else
					valores[indiceVariable++] = 0;
		}
		// valor para la función objetivo.
		double fObjetivo = 0;

		// valores para los d
		for (int color = 0; color < colores; color++) {
			if (valoresD[color] == 1)
				fObjetivo++;
			valores[indiceVariable++] = valoresD[color];
		}

		
		setSolution(variables, valores, fObjetivo);
	}
}
