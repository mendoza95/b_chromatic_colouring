package b.col.solver;

import ilog.concert.IloException;
import ilog.cplex.IloCplex.MIPInfoCallback;

public class CPLEXInfoCallBack extends MIPInfoCallback {

	private int mejorSolEntera = Integer.MIN_VALUE;
	

	@Override
	protected void main() throws IloException {
		
		mejorSolEntera = (int) Math.max(mejorSolEntera, getIncumbentObjValue());
		GlobalStatistics.getInstance().mejorSolEntera = mejorSolEntera;
		GlobalStatistics.getInstance().bestBound = getBestObjValue();
		
	}

	public int getMejorSolEntera() {
		return mejorSolEntera;
	}
}
