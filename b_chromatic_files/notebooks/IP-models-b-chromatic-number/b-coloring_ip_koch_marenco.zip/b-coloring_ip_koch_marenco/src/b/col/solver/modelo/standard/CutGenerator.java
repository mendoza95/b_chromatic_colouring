package b.col.solver.modelo.standard;

import b.col.solver.GlobalStatistics;
import ilog.concert.IloException;
import ilog.cplex.IloCplex;

public class CutGenerator extends IloCplex.UserCutCallback {
	IloCplex cplex;
	BColModelStandard model;

	// Numero de activacion
	private static int activacion = 0;

	public CutGenerator(IloCplex cplex, BColModelStandard model) {
		this.cplex = cplex;
		this.model = model;
	}

	@Override
	protected void main() throws IloException {
		// Genera la solucion
		int n = model.getG().getVertices();
		int colores = model.getColores();
		SolucionFraccionaria solucion = new SolucionFraccionaria(this.model.getG(), this.model.getColores());

		for (int v = 0; v < n; ++v)
			for (int c = 0; c < colores; ++c) {
				solucion.setX(v, c, this.getValue(this.model.getX()[v][c]));
				if (model.getG().getGrado(v) >= colores - 1)
					solucion.setZ(v, c, this.getValue(this.model.getZ()[v][c]));
			}

		activacion++;
		// System.err.println("Procedimiento de separacion, activacion " +
		// activacion);


		// Ejecuta la separacion
		if (activacion % model.getConfiguracion().cortarCada == 0) {
			
			Separator separator = new Separator(model.getG(), model.getColores(), solucion, model.getConfiguracion());
			separator.separar();

			// Agrega las desigualdades
			for (Desigualdad dv : separator.getDesigualdades()) {
				// dv.mostrar(solucion);

				// if( dv.porcentajeViolacion(solucion) < 0.05 )
				// continue;
				this.add(dv.buildCut(cplex, model));
				// IloNumExpr cut = cplex.linearIntExpr();
				// cut = cplex.sum(cut, cplex.prod(dv.getCoeficienteZ(),
				// model.getZ()[dv.getZ()][dv.getC()]));
				//
				// for (int v = 0; v < n; ++v)
				// for (int c = 0; c < colores; ++c)
				// cut = cplex.sum(cut, cplex.prod(dv.getCoeficienteX(v, c),
				// model.getX()[v][c]));
				//
				// this.add(cplex.le(cut, dv.getRhs()));
			}
			System.out.println(GlobalStatistics.getInstance().toString());
		}

	}
}
