package b.col.solver.modelo.standard;

import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import b.col.solver.CPLEXInfoCallBack;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.Grafo.Arista;
import b.col.solver.GraphColoringUtils;

public class BColModelStandard {

	private Grafo g;
	private int colores;
	private IloNumVar[][] x;
	private IloNumVar[][] z;
	private IloNumVar[] d;
	private Configuracion configuracion;

	public BColModelStandard(Grafo g, int colores) {

		this.g = g;
		this.colores = colores;

	}

	// Resuelve el problema entero
	public Solucion solve(Configuracion configuracion) throws Exception {

		return solve(configuracion, new ByteArrayOutputStream());

	}

	public Solucion solve(Configuracion configuracion, OutputStream baos) throws Exception {

		this.configuracion = configuracion;
		GlobalStatistics.getInstance().nOriginal = g.getVertices();
		GlobalStatistics.getInstance().mOriginal = g.getAristas().size();

		if (configuracion.graphReduction) {

			this.g = Preprocesador.grafoReducido(this.g, colores);
			GlobalStatistics.getInstance().nReducido = this.g.getVertices();
			GlobalStatistics.getInstance().mReducido = this.g.getAristas().size();
		}

		// create CPLEX optimizer/modeler
		IloCplex cplex = new IloCplex();

		// build model
		IloNumVar[][][] var = new IloNumVar[2][][];
		IloNumVar[][] var2 = new IloNumVar[1][];

		IloRange[][] rng = new IloRange[1][];

		int cantVariablesEfectiva = g.getVertices() * colores + colores;

		// variables x
		x = new IloNumVar[g.getVertices()][colores];
		for (int i = 0; i < g.getVertices(); ++i)
			for (int j = 0; j < colores; ++j)
				x[i][j] = cplex.boolVar();

		// variables z
		z = new IloNumVar[g.getVertices()][colores];
		for (int i = 0; i < g.getVertices(); ++i)
			if (g.getGrado(i) >= colores - 1)
				for (int j = 0; j < colores; ++j) {
					z[i][j] = cplex.boolVar();
					cantVariablesEfectiva++;
				}

		// variables d
		d = new IloNumVar[colores];
		for (int j = 0; j < colores; ++j)
			d[j] = cplex.boolVar();

		var[0] = x;
		var[1] = z;
		var2[0] = d;

		// objective function
		IloNumExpr fobj = cplex.linearIntExpr();
		for (int i = 0; i < colores; ++i)
			fobj = cplex.sum(fobj, cplex.prod(1, d[i]));

		cplex.addMaximize(fobj);

		// constraints
		ArrayList<IloRange> restricciones = new ArrayList<IloRange>();

		// a cada vértice le corresponde exactamente un color
		for (int v = 0; v < g.getVertices(); ++v) {

			IloNumExpr lhs = cplex.linearIntExpr();
			for (int c = 0; c < colores; c++)
				lhs = cplex.sum(lhs, cplex.prod(1.0, x[v][c]));

			restricciones.add(cplex.addEq(lhs, 1, "UnColor:" + v));
		}

		// xvc + xwc <= 1 si vw ady.
		for (int c = 0; c < colores; ++c) {
			Set<Arista> aristas = g.getAristas();
			for (Arista arista : aristas) {

				IloNumExpr lhs = cplex.linearIntExpr();
				lhs = cplex.sum(lhs, cplex.prod(1.0, x[arista.getI()][c]));
				lhs = cplex.sum(lhs, cplex.prod(1.0, x[arista.getJ()][c]));
				restricciones.add(cplex.addLe(lhs, 1, "Ady" + arista));
			}
		}

		// restricción de dominancia.
		for (int c = 0; c < colores; ++c)
			for (int f = 0; f < colores; ++f)
				if (f != c)
					for (int v = 0; v < g.getVertices(); ++v) {
						if (g.getGrado(v) >= colores - 1) {
							Set<Integer> vecinos = g.getVecinos(v);
							IloNumExpr lhs = cplex.linearIntExpr();
							lhs = cplex.sum(lhs, cplex.prod(1.0, z[v][c]));

							for (Integer w : vecinos)
								lhs = cplex.sum(lhs, cplex.prod(-1.0, x[w][f]));

							restricciones.add(cplex.addLe(lhs, 0, "Dom" + v));
						}
					}

		// restricción de las ds
		for (int c = 0; c < colores; ++c) {
			IloNumExpr lhs = cplex.linearIntExpr();
			lhs = cplex.sum(lhs, cplex.prod(1.0, d[c]));

			for (int v = 0; v < g.getVertices(); ++v)
				if (g.getGrado(v) >= colores - 1)
					lhs = cplex.sum(lhs, cplex.prod(-1.0, z[v][c]));

			restricciones.add(cplex.addLe(lhs, 0, "Rest para d: " + c));
		}

		// restricción para eliminar simetría
		if (configuracion.conRestSimetria) {
			for (int c = colores - 1; c > 0; c--)
				for (int v = 0; v < g.getVertices(); ++v) {
					IloNumExpr lhs = cplex.linearIntExpr();
					lhs = cplex.sum(lhs, cplex.prod(1.0, x[v][c]));

					for (int w = 0; w < g.getVertices(); w++)
						if (w != v)
							lhs = cplex.sum(lhs, cplex.prod(-1.0, x[w][c - 1]));

					restricciones.add(cplex.addLe(lhs, 0, "Sim:" + v + "c=" + c));
				}
		}
		rng[0] = new IloRange[restricciones.size()];

		int t = 0;
		for (IloRange range : restricciones)
			rng[0][t++] = range;

		// cplex.exportModel("modelo.lp");

		// cut callback
		if (configuracion.conCuts) {
			CutGenerator generator = new CutGenerator(cplex, this);
			cplex.use(generator);
		}

		CPLEXInfoCallBack infocallback = new CPLEXInfoCallBack();
		cplex.use(infocallback);
		long start = System.currentTimeMillis();
		if (configuracion.initialSol) {

			int[] solInicial = Preprocesador.solucionInicialMejorada(this.g, colores);
			Set<Integer> dominantes = GraphColoringUtils.verticesDominantes(g, solInicial);
			Set<Integer> colDominantes = GraphColoringUtils.coloresDominantes(g, solInicial);

			if (colores != GraphColoringUtils.coloresUsados(solInicial))
				throw new RuntimeException("Solucion inicial no tiene suficientes colores");

			IloNumVar[] startVar = new IloNumVar[cantVariablesEfectiva];
			// IloNumVar[] startVar = new IloNumVar[g.getVertices() * colores *
			// 2 + colores];

			double[] startVal = new double[cantVariablesEfectiva];

			// double[] startVal = new double[g.getVertices() * colores * 2 +
			// colores];
			int indice = 0;
			for (int i = 0; i < g.getVertices(); ++i)
				for (int j = 0; j < colores; ++j) {
					startVar[indice] = x[i][j];
					if (solInicial[i] == j)
						startVal[indice] = 1.0;
					indice++;
				}

			for (int i = 0; i < g.getVertices(); ++i)
				if (g.getGrado(i) >= colores - 1)
					for (int j = 0; j < colores; ++j) {
						startVar[indice] = z[i][j];
						if (dominantes.contains(i) && solInicial[i] == j)
							startVal[indice] = 1.0;
						indice++;
					}

			for (int j = 0; j < colores; ++j) {
				startVar[indice] = d[j];
				if (colDominantes.contains(j))
					startVal[indice] = 1.0;
				indice++;
			}

			cplex.addMIPStart(startVar, startVal);
			startVar = null;
			startVal = null;
		}

		// if (conHeuristica) {
		// DSATURHeuristicCallback dsaturH = new DSATURHeuristicCallback(this);
		// cplex.use(dsaturH);
		// }

		// CPLEXInfoCallBack infocallback = new CPLEXInfoCallBack();
		// cplex.use(infocallback);

		cplex.setOut(baos);

		// cplex.setParam(IloCplex.IntParam.NodeLim, 0);
		// // cplex.setParam(IloCplex.IntParam.BndStrenInd, 1);
		//
		// cplex.setParam(IloCplex.IntParam.Cliques, -1);
		// cplex.setParam(IloCplex.IntParam.ZeroHalfCuts, -1);
		// cplex.setParam(IloCplex.IntParam.FracCuts, -1);
		cplex.setParam(IloCplex.DoubleParam.TiLim, configuracion.timeLim);
		cplex.setParam(IloCplex.IntParam.AdvInd, 1);
		// optimize and output solution information
		
		boolean ok = cplex.solve();
		long end = System.currentTimeMillis();

		GlobalStatistics stat = GlobalStatistics.getInstance();
		stat.timeMillis = (end - start);
		System.out.print(baos.toString());

		stat.gap = cplex.getMIPRelativeGap();
		stat.mejorSolEntera = cplex.getObjValue();
		stat.status = cplex.getCplexStatus();

		stat.bestBound = cplex.getBestObjValue();

		if (ok) {

			// System.out.print(GlobalStatistics.getInstance());
			Set<Integer> dominantes = new HashSet<Integer>();

			for (int v = 0; v < g.getVertices(); v++)
				for (int color = 0; color < colores; color++)
					if (g.getGrado(v) >= colores - 1 && cplex.getValue(z[v][color]) > 0)
						dominantes.add(v);

			Solucion sol = new Solucion(g, colores, (int) Math.round(cplex.getObjValue()), dominantes);
			for (int v = 0; v < g.getVertices(); v++)
				for (int color = 0; color < colores; color++)
					if (cplex.getValue(x[v][color]) > 0)
						sol.setColor(v, color);
			return sol;
		} else
			return null;

	}

	public Grafo getG() {
		return g;
	}

	public void setG(Grafo g) {
		this.g = g;
	}

	public int getColores() {
		return colores;
	}

	public void setColores(int colores) {
		this.colores = colores;
	}

	public IloNumVar[][] getX() {
		return x;
	}

	public IloNumVar[][] getZ() {
		return z;
	}

	public IloNumVar[] getD() {
		return d;
	}

	public Configuracion getConfiguracion() {
		return configuracion;
	}

}
