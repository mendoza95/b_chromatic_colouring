package b.col.solver.modelo.representantes;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;

import java.util.Set;

import b.col.solver.Grafo;
import b.col.solver.modelo.representantes.SolucionFraccionaria;

public class DesigualdadTipo1 extends AbstractDesigualdad{

	// Coeficientes y termino independiente

	// Cantidad de variables

	private int v;
	private Set<Integer> U;
	

	// Constructor
	public DesigualdadTipo1(Grafo g, int v, Set<Integer> U) {

		super(g, g.getVertices());
		this.v = v;
		this.U = U;		

		if (U.contains(v))
			throw new RuntimeException("v está contenido en U!");
	}
	
	public IloRange buildCut(IloCplex cplex, BColModelRepresentatives model) throws IloException {
		IloNumExpr cut = cplex.linearIntExpr();

		for (int u : U)
			cut = cplex.sum(cut, cplex.prod(getCoeficienteX(u, u), model.getX()[u][u]));

		cut = cplex.sum(cut, cplex.prod(getCoeficienteX(v, v), model.getX()[v][v]));

		for (int u : U)
			for (int w : g.getVecinos(v))
				if (model.getValidX()[u][w])
					cut = cplex.sum(cut, cplex.prod(getCoeficienteX(u, w), model.getX()[u][w]));				

		return cplex.le(cut, this.rhs);
	}



	public double getCoeficienteX(int i, int j) {

		checkRange(i);
		checkRange(j);

		Set<Integer> Nv = g.getVecinos(v);
		if (i == j) {
			if (i == this.v)
				return n;
			else if (U.contains(i)) {
				if (Nv.contains(i))
					return 0;
				else
					return 1;
			} else
				return 0;
		} else {
			if (U.contains(i) && Nv.contains(j))
				return -1;
			else
				return 0;
		}
	}

	// Consulta el LHS en la solucion indicada
	public double getLHS(SolucionFraccionaria solucion) {

		double _lhs = 0;
		Set<Integer> Nv = g.getVecinos(v);
		for (int u : U)
			_lhs += getCoeficienteX(u, u) * solucion.getX(u, u);

		_lhs += getCoeficienteX(v, v) * solucion.getX(v, v);

		for (int u : U)
			for (int w : Nv)
				_lhs += getCoeficienteX(u, w) * solucion.getX(u, w);

		return _lhs;
	}
}
