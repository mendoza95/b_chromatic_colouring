package b.col.solver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DSATUR {

	private List<Integer> porColorear = null;
	private int[] coloreoParcial;
	private Grafo g;
	private int maxCantColores;


	public DSATUR(Grafo g) {
		this.g = g;
		this.coloreoParcial = new int[this.g.getVertices()];
		this.porColorear = new ArrayList<Integer>(g.verticesPorGradoDescendente());	
		this.maxCantColores = g.getGradoMaximo() + 1;
	}

	public DSATUR(Grafo g, int[] precoloreo) {
		this.g = g;
		this.coloreoParcial = precoloreo;
		this.porColorear = new ArrayList<Integer>(g.verticesPorGradoDescendente());
		this.maxCantColores = g.getGradoMaximo() + 1;

		for (int v = 0; v < g.getVertices(); v++) {
			if (this.coloreoParcial[v] > -1)
				this.porColorear.remove(Integer.valueOf(v));
		}
	}
	
	public DSATUR(Grafo g, int[] precoloreo, int maxCantColores) {
		this.g = g;
		this.coloreoParcial = precoloreo;
		this.porColorear = new ArrayList<Integer>(g.verticesPorGradoDescendente());
		this.maxCantColores = maxCantColores;
		
		for (int v = 0; v < g.getVertices(); v++) {
			if (this.coloreoParcial[v] > -1)
				this.porColorear.remove(Integer.valueOf(v));
			if (this.coloreoParcial[v] > maxCantColores - 1)
				throw new IllegalArgumentException("Max cantidad de colores superada en el precoloreo");
		}
	}

	public int[] color() {
		
		int sinColorear = this.porColorear.size();
		for (int vertProc = 0; vertProc < sinColorear; vertProc++) {
			int v = -1;
			if (vertProc == 0)
				v = firstVertex(g);
			else 
				v = nextVertex(g);
			colorGreedily(v);
			this.porColorear.remove(Integer.valueOf(v));
		}
		return this.coloreoParcial;
	}

	private int firstVertex(Grafo g) {

		return porColorear.get(0);

	}

	private int nextVertex(Grafo g) {

		int maxSatDeg = -1;
		int vertMaxSat = -1;

		for (int v : this.porColorear) {
			int satDeg = satDegree(v);
			
			if (maxSatDeg < satDeg) {
				maxSatDeg = satDeg;
				vertMaxSat = v;
			} else if (maxSatDeg == satDeg)
				vertMaxSat = breakTieMaxDegree(v, vertMaxSat);
		}

		return vertMaxSat;

	}

	private int breakTieMaxDegree(int v, int w) {		

		if (this.g.getGrado(v) > this.g.getGrado(w))
			return v;
		else
			return w;
	}
	
//	private int breakTie(int v, int w) {
//		int vecNoColV = vecinosNoColoreados(v);
//		int vecNoColW = vecinosNoColoreados(w);
//
//		if (vecNoColV > vecNoColW)
//			return v;
//		else
//			return w;
//	}

//	private int vecinosNoColoreados(int v) {
//		Set<Integer> Nv = g.getVecinos(v);
//
//		Set<Integer> noColoreadosV = new HashSet<Integer>();
//		for (int w : Nv) {
//			if (coloreoParcial[w] == -1)
//				noColoreadosV.add(w);
//		}
//		return noColoreadosV.size();
//	}

	private int satDegree(int v) {
		Set<Integer> Nv = g.getVecinos(v);

		Set<Integer> colsUsados = new HashSet<Integer>();
		for (int w : Nv) {
			colsUsados.add(coloreoParcial[w]);
		}

		return colsUsados.size();
	}

	private void colorGreedily(int v) {

		Set<Integer> Nv = g.getVecinos(v);

		boolean[] usados = new boolean[maxCantColores];
		
		for (int w : Nv) {
			int colorW = coloreoParcial[w];		
			if (colorW > -1)
				usados[colorW] = true;
		}
		
		for (int c = 0; c < maxCantColores; c++)
			if (!usados[c]) {
				coloreoParcial[v] = c;
				return;
			}
			
		throw new IllegalArgumentException("Max cantidad de colores superada");
	}
}
