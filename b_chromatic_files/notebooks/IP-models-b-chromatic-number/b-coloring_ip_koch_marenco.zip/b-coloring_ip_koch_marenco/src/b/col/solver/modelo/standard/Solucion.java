package b.col.solver.modelo.standard;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.Grafo.Builder;

public class Solucion {

	private Grafo g;

	// Colores de los vertices
	private int[] coloreo;

	// Cantidad de colores usados
	private int colores;
	// Constructor

	private int coloresDominantes;

	private Set<Integer> dominantes;

	public Solucion(Grafo g, int c, int coloresDom, Set<Integer> dominantes) {
		this.g = g;
		coloreo = new int[g.getVertices()];
		this.colores = c;
		this.coloresDominantes = coloresDom;
		this.dominantes = dominantes;
	}

	public void setColor(int i, int x) {
		if (i < 0 || i >= g.getVertices())
			throw new IllegalArgumentException();

		if (x < 0 || x >= colores)
			throw new IllegalArgumentException();

		if (coloreo[i] > 0)
			throw new IllegalArgumentException("El vértice i ya fue coloreado");

		coloreo[i] = x;
	}

	public int getColor(int i) {
		if (i < 0 || i >= g.getVertices())
			throw new IllegalArgumentException();

		return coloreo[i];
	}

	public boolean esBColoreo() {

		return (dominantesOK() && dominantes.size() == colores);
	}

	/***
	 * Los que se indican como dominantes lo son?
	 * 
	 * @return
	 */
	public boolean dominantesOK() {

		if (!esColoreo())
			return false;

		for (int v : dominantes) {

			Set<Integer> coloresEnNv = new HashSet<Integer>();
			coloresEnNv.add(getColor(v));
			for (int w : g.getVecinos(v))
				coloresEnNv.add(getColor(w));

			if (coloresEnNv.size() < colores)
				return false;
		}

		return true;
	}

	public int getColores() {
		return this.colores;
	}

	public boolean esColoreo() {
		return GraphColoringUtils.esColoreo(this.g, this.coloreo);
	}
	
	public void toTxt(String fileName) throws UnsupportedEncodingException, FileNotFoundException, IOException{
		
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "utf-8"))) {
			writer.write(this.toString());
		}
	}

	@Override
	public String toString() {
		String s = "";
		s += "c " + colores + "\n";
		s += "d " + coloresDominantes + "\n";
		s += "D \n";
		for (int v : dominantes)
			s +=  v + "\n";
		s += "\nS\n";
		for (int v = 0; v < g.getVertices(); v++)
			s += v + " " + coloreo[v] + "\n";

		return s;
	}
	
	public static Solucion loadFromTxt(Grafo g, String fileName) throws FileNotFoundException {
		FileInputStream fis = new FileInputStream(fileName);
		Scanner scanner = new Scanner(fis);
		
	
		int colores = 0;
		int coloresDom = 0;
		Set<Integer> dominantes = new HashSet<Integer>();
		int[] coloreo = new int[g.getVertices()]; 
		
		boolean recorriendoDom = false;
		boolean recorriendoCol = false;
		try {

			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();

				if (linea.isEmpty())
					continue;

				if (linea.charAt(0) == 'c'){
					colores = Integer.parseInt(linea.split(" ")[1]);
					continue;
				}
				
				if (linea.charAt(0) == 'd'){
					coloresDom = Integer.parseInt(linea.split(" ")[1]);
					continue;
				}

				if (linea.charAt(0) == 'D'){
					recorriendoDom = true;
					continue;
				}
				

				if (linea.charAt(0) == 'S'){
					recorriendoDom = false;
					recorriendoCol = true;
					continue;
				}
				
				if (recorriendoDom){
					 dominantes.add(Integer.parseInt(linea));
					 continue;
				}
				if (recorriendoCol){
					 coloreo[Integer.parseInt(linea.split(" ")[0])] = Integer.parseInt(linea.split(" ")[1]);
					 continue;
				}
			}
		} finally {
			scanner.close();
		}

		Solucion s = new Solucion(g, colores, coloresDom, dominantes);
		s.coloreo = coloreo;
		
		return s;
	}


	public int[] getColoreo() {
		return coloreo;
	}

	public Set<Integer> getDominantes() {
		return dominantes;
	}
}
