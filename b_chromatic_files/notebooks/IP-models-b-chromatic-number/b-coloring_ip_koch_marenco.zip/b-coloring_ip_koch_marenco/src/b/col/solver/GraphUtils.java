package b.col.solver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Scanner;

import b.col.solver.Grafo.Builder;

/**
 * Graph utility class.
 * 
 * @author ik
 * 
 */
public abstract class GraphUtils {

	/**
	 * Saves a graph to a txt file.
	 * 
	 * @param fileName
	 * @param graph
	 * @throws UnsupportedEncodingException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void saveToTxt(String fileName, Grafo graph) throws UnsupportedEncodingException, FileNotFoundException, IOException {

		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "utf-8"))) {
			writer.write(graph.toString());
		}
	}

	public static void saveToTxt(String fileName, Grafo graph, String addenda) throws UnsupportedEncodingException, FileNotFoundException,
			IOException {

		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), "utf-8"))) {
			writer.write(addenda + "\n");
			writer.write(graph.toString());
		}
	}
	
	public static Grafo loadFromDIMACSTxt(String fileName) throws FileNotFoundException {
		FileInputStream fis = new FileInputStream(fileName);
		Scanner scanner = new Scanner(fis);
		Builder b = null;
		try {

			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();

				if (linea.isEmpty())
					continue;

				if (linea.charAt(0) == 'p')
					b = new Builder(Integer.parseInt(linea.split(" ")[2]));

				if (linea.charAt(0) == 'e')
					b.setArista(Integer.parseInt(linea.split(" ")[1]) - 1, Integer.parseInt(linea.split(" ")[2]) - 1);
			}
		} finally {
			scanner.close();
		}

		return b.build();
	}

	/**
	 * Loads a graph from a txt file.
	 * 
	 * @param fileName
	 * @return
	 */
	public static Grafo loadFromTxt(String fileName) {

		try {

			File inputFile = new File(fileName);
			RandomAccessFile in = new RandomAccessFile(inputFile, "r");

			String line;
			int lines = 1;
			int begVertex;
			int endVertex;
			boolean firstLine = true;

			Builder b = null;
			while ((line = in.readLine()) != null) {
				if (!(line.startsWith("#")) && !line.equals("\n") && !line.equals("")) {
					if (firstLine) {												
						lines = Integer.parseInt(line.trim());
						firstLine = false;
						b = new Builder(lines);

					} else {
						int commaIndex = line.indexOf(",");
						begVertex = Integer.parseInt(line.substring(0, commaIndex).trim());
						endVertex = Integer.parseInt(line.substring(commaIndex + 1).trim());

						b.setArista(begVertex, endVertex);
					}
				}

			}
			in.close();

			return b.build();

		} catch (Exception e) {
			System.out.println("Error en: GraphUtils.loadFromTxt()");
			System.out.println("Archivo de entrada erróneo.");
			e.printStackTrace(System.out);

			return null;
		}
	}
	
	
	
}
