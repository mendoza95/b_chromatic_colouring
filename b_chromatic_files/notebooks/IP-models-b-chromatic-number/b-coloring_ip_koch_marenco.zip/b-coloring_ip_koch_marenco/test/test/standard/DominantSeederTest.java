package test.standard;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.logging.Logger;

import org.junit.Test;

import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.DominantSeeder;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;

public class DominantSeederTest {

	private void testear(Grafo g) {

		// Grafo g = GraphUtils.loadFromDIMACSTxt("./instances/C125.9.clq");

		DSATUR dsatur = new DSATUR(g);
		int[] coloreo = dsatur.color();
		int lowerBound = GraphColoringUtils.coloresUsados(coloreo);
		int upperBound = BColUpperBound.upperBound(g);
		int medBound = (upperBound + lowerBound) / 2;

		for (int colores = lowerBound; colores <= upperBound; colores++) {

			System.out.println("C" + colores + "Colores dominantes antes " + GraphColoringUtils.coloresDominantes(g, coloreo).size());

			DominantSeeder ds = new DominantSeeder(g, colores, coloreo);

			int sembrados = ds.seed();

			int[] nuevoColoreo = ds.getColoreo();

			// System.out.println("Sembrados " + sembrados);
			// System.out.println("Dominantes después " +
			// GraphColoringUtils.verticesDominantes(g, nuevoColoreo).size());
			System.out.println("Colores dominantes después " + GraphColoringUtils.coloresDominantes(g, nuevoColoreo).size());

			assertTrue(GraphColoringUtils.esColoreo(g, nuevoColoreo));
		}

	}

	@Test
	public void test() throws IOException {

		String directory = "./random";
		DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));

		for (Path p : ds) {

			if (Files.isDirectory(p))
				continue;
			// Iteramos por todos los archivos del directorio y resolvemos
			Grafo g;
			String nombreGrafo = p.getFileName().toString();

			g = GraphUtils.loadFromTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

			testear(g);
		}
	}

	@Test
	public void testSingle() throws IOException {

		Grafo g = GraphUtils.loadFromTxt("./random/G_30_4");

		testear(g);

	}
	//
	// @Test
	// public void testLarge() throws FileNotFoundException {
	//
	// Grafo g = GraphUtils.loadFromDIMACSTxt("./instances/C125.9.clq");
	// assertTrue(GraphColoringUtils.esColoreo(g, resolver(g)));
	// }
	//
	// @Test
	// public void testVeryLarge() throws Exception {
	//
	// String directory = "./instances";
	//
	// DirectoryStream<Path> ds =
	// Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));
	//
	// for (Path p : ds) {
	// // Iteramos por todos los archivos del directorio y resolvemos
	// Logger.getLogger(Logger.GLOBAL_LOGGER_NAME).info(p.getFileName() + ":");
	// Grafo g = GraphUtils.loadFromDIMACSTxt(directory +
	// FileSystems.getDefault().getSeparator() + p.getFileName());
	// resolver(g);
	// }
	// }
}
