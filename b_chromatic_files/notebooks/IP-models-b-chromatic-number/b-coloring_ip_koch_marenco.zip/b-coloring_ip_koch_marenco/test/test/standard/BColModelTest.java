package test.standard;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class BColModelTest {

	@Test
	public void testGrafosRandom() throws Exception {

		for (int n = 10; n < 30; n += 10) {
			for (int d = 1; d < 5; d++) {
				
				String nombreGrafo = "G_" + n + "_" + d;

				Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
				int upperBound = BColUpperBound.upperBound(g);
				DSATUR dsatur = new DSATUR(g);
				int lowerBound = GraphColoringUtils.coloresUsados(dsatur.color());

				int[] coloresParaProbar = { lowerBound, (lowerBound + upperBound) / 2, upperBound };
				for (int colores : coloresParaProbar)
					test(g, colores);
			}
		}
	}

	@Test
	public void testGrafoEjemplo() throws Exception {

		Grafo g = GraphUtils.loadFromTxt("testGraph");
		int upperBound = BColUpperBound.upperBound(g);
		test(g, upperBound);
	}

	public void test(Grafo g, int colores) throws Exception {

		List<Configuracion> configuraciones = crearConfiguraciones();

		List<Double> soluciones = new ArrayList<Double>();
		for (Configuracion conf : configuraciones) {
			BColModelStandard model = new BColModelStandard(g, colores);

			Solucion sol = model.solve(conf);
			assertTrue(sol.dominantesOK());

			soluciones.add(GlobalStatistics.getInstance().mejorSolEntera);

			GlobalStatistics.getInstance().clear();
			System.out.println(sol);
		}

		double primeraSol = soluciones.get(0);

		for (double solucion : soluciones)
			assertTrue(primeraSol == solucion);

	}

	private List<Configuracion> crearConfiguraciones() {
		List<Configuracion> configuraciones = new ArrayList<Configuracion>();

		// sin nada
		Configuracion configuracion1 = new Configuracion();
		configuracion1.timeLim = 300;
		configuracion1.conRestSimetria = false;
		configuracion1.conCuts = false;

		configuraciones.add(configuracion1);

		// con restricciones de simetría.
		Configuracion configuracion2 = new Configuracion();
		configuracion2.timeLim = 300;
		configuracion2.conRestSimetria = true;
		configuracion2.conCuts = false;

		configuraciones.add(configuracion2);

		// con cuts de tipo 1
		Configuracion configuracion3 = new Configuracion();
		configuracion3.timeLim = 300;
		configuracion3.conRestSimetria = false;
		configuracion3.conCuts = true;
		configuracion3.conCortes1 = true;

		configuraciones.add(configuracion3);

		// con cuts de tipo 2
		Configuracion configuracion4 = new Configuracion();
		configuracion4.timeLim = 300;
		configuracion4.conRestSimetria = false;
		configuracion4.conCuts = true;
		configuracion4.conCortes2 = true;

		configuraciones.add(configuracion4);

		// con cuts de tipo 3
		Configuracion configuracion5 = new Configuracion();
		configuracion5.timeLim = 300;
		configuracion5.conRestSimetria = false;
		configuracion5.conCuts = true;
		configuracion5.conCortes3y4 = true;

		configuraciones.add(configuracion5);

		// con cuts de tipo 4
		Configuracion configuracion6 = new Configuracion();
		configuracion6.timeLim = 300;
		configuracion6.conRestSimetria = false;
		configuracion6.conCuts = true;
		configuracion6.conCortes3y4 = true;

		configuraciones.add(configuracion6);

		// con cuts de tipo clique
		Configuracion configuracion7 = new Configuracion();
		configuracion7.timeLim = 300;
		configuracion7.conRestSimetria = false;
		configuracion7.conCuts = true;
		configuracion7.conCortesClique = true;

		configuraciones.add(configuracion7);

		// con todos los cortes
		Configuracion configuracion8 = new Configuracion();
		configuracion8.timeLim = 300;
		configuracion8.conRestSimetria = false;
		configuracion8.conCuts = true;
		configuracion8.conCortes1 = true;
		configuracion8.conCortes2 = true;
		configuracion8.conCortes3y4 = true;
		configuracion8.conCortes5 = true;
		configuracion8.conCortesClique = true;

		configuraciones.add(configuracion8);
		return configuraciones;
	}
	
	
	
}
