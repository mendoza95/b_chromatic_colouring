package test.standard;

import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Test;

import test.aux.TestUtils;
import b.col.solver.BColUpperBound;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class BColStandardCliqueIneq {

	@Test
	public void testPerformanceCliqueIneq() throws Exception {

		String nombreGrafo = "DSJC125.1.col";

		//Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
		Grafo g = GraphUtils.loadFromDIMACSTxt("./random/" + nombreGrafo);
		
		Map<String, int[]> bounds = GraphColoringUtils.uploadBounds("./logs/boundsRandom");

		int lowerBound = bounds.get(nombreGrafo)[0];
		int medBound = bounds.get(nombreGrafo)[1];
		int upperBound = bounds.get(nombreGrafo)[2];

	

		// sin cortes
		Configuracion configuracionSinCortes = new Configuracion();
		configuracionSinCortes.timeLim = 180;
		configuracionSinCortes.conRestSimetria = true;
		configuracionSinCortes.conCuts = false;
		configuracionSinCortes.graphReduction = true;
		configuracionSinCortes.initialSol = true;

		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = 180;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = false;
		configuracionConCortes.conCortesClique = true;
		configuracionConCortes.graphReduction = true;
		configuracionConCortes.initialSol = true;

		BColModelStandard model = new BColModelStandard(g, upperBound);

		//Solucion sol = model.solve(configuracionSinCortes);
		//System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionSinCortes));
		
		Solucion sol2 = model.solve(configuracionConCortes);

		System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionConCortes));

		//assertTrue(sol.dominantesOK());
		assertTrue(sol2.dominantesOK());
	}

}
