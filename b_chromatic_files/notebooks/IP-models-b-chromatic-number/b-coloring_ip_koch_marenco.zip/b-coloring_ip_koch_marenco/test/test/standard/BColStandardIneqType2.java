package test.standard;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import test.aux.TestUtils;
import b.col.solver.BColUpperBound;
import b.col.solver.Grafo;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class BColStandardIneqType2 {

	@Test
	public void testPerformanceType2Ineq() throws Exception {

		String nombreGrafo = "DSJC125.1.col";

		//Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
		Grafo g = GraphUtils.loadFromDIMACSTxt("./random/" + nombreGrafo);
		int upperBound = BColUpperBound.upperBound(g);

		
		// con cortes clique
		Configuracion configuracionConCortes = new Configuracion();
		configuracionConCortes.timeLim = 180;
		configuracionConCortes.conRestSimetria = true;
		configuracionConCortes.conCuts = true;
		configuracionConCortes.conCortes1 = false;
		configuracionConCortes.conCortes2 = true;
		
		
		configuracionConCortes.conCortesClique = false;
		configuracionConCortes.graphReduction = true;
		configuracionConCortes.initialSol = true;

		BColModelStandard model = new BColModelStandard(g, upperBound);

		//Solucion sol = model.solve(configuracionSinCortes);
		//System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionSinCortes));
		
		Solucion sol2 = model.solve(configuracionConCortes);

		System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionConCortes));

		//assertTrue(sol.dominantesOK());
		assertTrue(sol2.dominantesOK());
	}

}
