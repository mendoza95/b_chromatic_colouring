package test.aux;

import java.io.FileNotFoundException;
import java.io.IOException;

import b.col.solver.BColUpperBound;
import b.col.solver.Grafo;
import b.col.solver.GraphUtils;

public class TestBenchGenerator {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		//String pathSalida = "/home/ik/Dropbox/Doctorado/IP proyectos/b-col-claio/test-instances/";
		String pathSalida = "/Users/fabriciomendozagranada/Documents/PhD Work/Implementation/b_chromatic/experiment_results/programming_models/IP_KOCH_MARENCO/";
		int cantAGenerar = 50;

		for (int i = 0; i < cantAGenerar; i++) {
			boolean encontramos = false;
			Grafo g = null;
			while (!encontramos) {
				g = GraphGenerator.randomGraph(10 + i, 0.3f);
				// sin vertices universales.
				encontramos = g.verticesPorGradoDescendente().get(0) < g.getVertices() - 1;
			}
			// DSATUR dsatur = new DSATUR(g);
			// int[] coloreo = dsatur.color();
			//
			// int maxCol = 0;
			// for (int v = 0; v < g.getVertices(); v++)
			// maxCol = Math.max(maxCol, coloreo[v]);

			int upperBound = BColUpperBound.upperBound(g);
			// List<Integer> vertGrDesc = g.verticesPorGradoDescendente();
			// int j = upperBound;
			// int[] req = new int[g.getVertices()];
			// for (int v : vertGrDesc) {
			// req[v] = j > 0 ? upperBound : 0;
			// j--;
			// }
			String addenda = "c = " + upperBound + ";\n";
			// addenda += "req = " + Arrays.toString(req) + ";\n";

			GraphUtils.saveToTxt(pathSalida + "G_" + i + ".dat", g, addenda);

		}

	}

}
