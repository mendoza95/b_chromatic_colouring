package test.aux;

import b.col.solver.GlobalStatistics;
import b.col.solver.modelo.standard.Configuracion;

public class TestUtils {

	public static String printResults(String nombreGrafo, int colores, Configuracion configuracion) {
		String log = nombreGrafo;

		GlobalStatistics stat = GlobalStatistics.getInstance();
		log += "|COL " + colores + "|" + stat.toString();

		log += "|" + configuracion.toString();

		return log;

	}

}
