package test.rep;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;

import org.junit.Test;

import test.aux.GraphGenerator;
import b.col.solver.GlobalStatistics;
import b.col.solver.Grafo;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.representantes.BColModelRepresentatives;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class BColRepModelTest {

	// @Test
	public void testSmall() throws Exception {

		// Grafo g = GraphGenerator.randomGraph(10);
		Grafo g = GraphUtils.loadFromTxt("testGraph");

		solveAndAssertRep(g);
	}

	private void solveAndAssertRep(Grafo g) throws Exception {

		BColModelRepresentatives model = new BColModelRepresentatives(g);
		// SplitWindow splitWindow = new SplitWindow(model);
		// ByteArrayOutputStream baos = new ByteArrayOutputStream();
		// Solucion sol = model.solve(g, false, baos);
		//
		// System.out.print(baos.toString());
		//
		// System.out.println(sol);
		// assertTrue(sol.esBColoreo());

		ByteArrayOutputStream baos2 = new ByteArrayOutputStream();

		Configuracion configuracion = new Configuracion();
		configuracion.conCuts = true;

		Solucion sol2 = model.solve(configuracion, baos2);

		System.out.print(baos2.toString());

		System.out.println(sol2);
		assertTrue(sol2.esBColoreo());

		// assertTrue(sol.getColores() == sol2.getColores());

	}

	@Test
	public void testRepLarge() throws Exception {

		Grafo g = GraphGenerator.randomGraph(50, 0.3f);
		// Grafo g = GraphUtils.loadFromDIMACSTxt("./instances/C125.9.clq");

		solveAndAssertRep(g);
		System.out.println(GlobalStatistics.getInstance());

	}
}
