package test.general;

import static org.junit.Assert.assertTrue;

import java.io.FileOutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import b.col.solver.BColUpperBound;
import b.col.solver.DSATUR;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.Preprocesador;

public class PreprocesadorTest {

	// @Test
	public void testSolucionInicial() {

		for (int n = 10; n < 160; n += 10) {
			for (int d = 1; d < 6; d++) {
				// if (n == 20 && d == 2) {
				String nombreGrafo = "G_" + n + "_" + d;
				try {
					Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
					int upperBound = BColUpperBound.upperBound(g);
					DSATUR dsatur = new DSATUR(g);
					int lowerBound = GraphColoringUtils.coloresUsados(dsatur.color());

					int[] coloresParaProbar = { lowerBound, (lowerBound + upperBound) / 2, upperBound };
					for (int colores : coloresParaProbar) {

						int[] sol = Preprocesador.solucionInicial(g, colores);

						assertTrue(GraphColoringUtils.esColoreo(g, sol));
						assertTrue(GraphColoringUtils.coloresUsados(sol) == colores);
						System.out.println(nombreGrafo + ":" + GraphColoringUtils.coloresDominantes(g, sol));
					}
				}

				catch (Exception ex) {
					ex.printStackTrace();
				} finally {
					System.gc();
				}
			}
		}
	}

	@Test
	public void testSingle() throws Exception {

		String directory = "./instances-dimacs/phase2";
		DirectoryStream<Path> ds = Files.newDirectoryStream(FileSystems.getDefault().getPath(directory));

		String boundsFileName = "./logs/boundsDimacs";

		Map<String, int[]> bounds = GraphColoringUtils.uploadBounds(boundsFileName);

		for (Path p : ds) {

			if (Files.isDirectory(p))
				continue;
			// Iteramos por todos los archivos del directorio y resolvemos
			Grafo g;
			String nombreGrafo = p.getFileName().toString();

			g = GraphUtils.loadFromDIMACSTxt(directory + FileSystems.getDefault().getSeparator() + nombreGrafo);

			int colores = bounds.get(nombreGrafo)[0];

			Grafo reducido = Preprocesador.grafoReducido(g, colores);

			Set<Integer> interesantes = new HashSet<Integer>();
			for (int v = 0; v < reducido.getVertices(); v++) {

				if (g.getGrado(v) < colores - 1) {
					int candVecinos = 0;
					Set<Integer> Nv = g.getVecinos(v);
					for (int w : Nv)
						if (g.getGrado(w) >= colores - 1)
							candVecinos++;

					if (candVecinos <= 2)
						interesantes.add(v);
				}
			}
			System.out.println("n " + g.getVertices() + " m " + g.getAristas().size());
			System.out.println("n red " + reducido.getVertices() + " m red" + reducido.getAristas().size());
			System.out.println("interesantes " + interesantes.size());

		}
	}

}
