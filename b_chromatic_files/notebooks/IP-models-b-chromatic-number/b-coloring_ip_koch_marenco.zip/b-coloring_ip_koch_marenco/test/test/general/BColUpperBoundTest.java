package test.general;


import org.junit.Assert;
import org.junit.Test;

import b.col.solver.BColUpperBound;
import b.col.solver.Grafo;
import b.col.solver.Grafo.Builder;

public class BColUpperBoundTest {

	@Test
	public void test() {
		
		Builder b = new Builder(4);
		
		b.setArista(0,1);
		b.setArista(1,2);
		b.setArista(2,0);
		b.setArista(2,3);
		Grafo g1 = b.build();
		Assert.assertTrue(BColUpperBound.upperBound(g1) == 3);
		
		Builder b2 = new Builder(10);
		b2.setArista(0,4);
		b2.setArista(1,9);
		b2.setArista(3,4);
		b2.setArista(3,8);
		b2.setArista(4,7);
				
		int ubg2 =BColUpperBound.upperBound(b2.build());
		Assert.assertTrue( ubg2 == 2);
		//Edges = {<1, 5>, <2, 10>, <4, 5>, <4, 9>, <5, 8>};
	}

}
