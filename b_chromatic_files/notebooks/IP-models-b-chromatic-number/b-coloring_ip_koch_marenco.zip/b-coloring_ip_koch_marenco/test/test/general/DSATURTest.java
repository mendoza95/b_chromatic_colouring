package test.general;

import java.io.FileNotFoundException;
import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

import b.col.solver.DSATUR;
import b.col.solver.Grafo;
import b.col.solver.GraphColoringUtils;
import b.col.solver.GraphUtils;

public class DSATURTest {

	@Test
	public void testDSATUR() {

		Grafo g = GraphUtils.loadFromTxt("testGraph");
		DSATUR dsatur = new DSATUR(g);
		int[] coloreo = dsatur.color();

		System.out.println("Colores usados " + GraphColoringUtils.coloresUsados(coloreo));
		Assert.assertTrue(GraphColoringUtils.esColoreo(g, coloreo));
	}
	
	@Test
	public void testDSATURPrecol() {

		Grafo g = GraphUtils.loadFromTxt("testGraph");
		int[] preColoreo = new int[g.getVertices()];
		Arrays.fill(preColoreo, -1);
		preColoreo[5] = 1;
		preColoreo[2] = 1;
		preColoreo[1] = 2;
		preColoreo[3] = 3;		
		
		DSATUR dsatur = new DSATUR(g, preColoreo);
		int[] coloreo = dsatur.color();
		
		System.out.println("Colores usados " + GraphColoringUtils.coloresUsados(coloreo));
		Assert.assertTrue(GraphColoringUtils.esColoreo(g, coloreo));
	}
	
	@Test
	public void testDSATURPrecolMaxCol() {

		Grafo g = GraphUtils.loadFromTxt("testGraph");
		int[] preColoreo = new int[g.getVertices()];
		Arrays.fill(preColoreo, -1);
		preColoreo[5] = 1;
		preColoreo[2] = 1;
		preColoreo[1] = 2;
		preColoreo[3] = 3;		
		
		DSATUR dsatur = new DSATUR(g, preColoreo, 1000);
		int[] coloreo = dsatur.color();
		
		Assert.assertTrue(GraphColoringUtils.esColoreo(g, coloreo));
	}

}
