package test.general;

import java.util.Set;

import org.junit.Test;

import b.col.solver.Grafo;
import b.col.solver.GraphUtils;

public class TestADistancia2 {

	@Test
	public void test() {
		

		Grafo g = GraphUtils.loadFromTxt("testGraph");
		
		Set<Integer> aDist2v2 = g.aDistancia2(2);
		Set<Integer> aDist2v3 = g.aDistancia2(3);
		Set<Integer> aDist2v4 = g.aDistancia2(5);
		Set<Integer> aDist2v7 = g.aDistancia2(7);
		Set<Integer> aDist2v8 = g.aDistancia2(8);
		

	}

}
