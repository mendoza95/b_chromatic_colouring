package test.general;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import test.aux.TestUtils;
import b.col.solver.BColUpperBound;
import b.col.solver.Grafo;
import b.col.solver.GraphUtils;
import b.col.solver.modelo.standard.BColModelStandard;
import b.col.solver.modelo.standard.Configuracion;
import b.col.solver.modelo.standard.Solucion;

public class GraphReductionTest {

	@Test
	public void testGraphReduction() throws Exception {

		for (int n = 10; n < 40; n += 10) {
			for (int d = 1; d < 5; d++) {
				// if (n == 20 && d == 2) {
				String nombreGrafo = "G_" + n + "_" + d;

				Grafo g = GraphUtils.loadFromTxt("./random/" + nombreGrafo);
				int upperBound = BColUpperBound.upperBound(g);

				// sin reduccion
				Configuracion configuracionSinRed = new Configuracion();
				configuracionSinRed.timeLim = 180;
				configuracionSinRed.conRestSimetria = true;
				configuracionSinRed.conCuts = false;

				// con reduccion
				Configuracion configuracionConReduction = new Configuracion();
				configuracionConReduction.timeLim = 180;
				configuracionConReduction.conRestSimetria = true;
				configuracionConReduction.conCuts = false;
				configuracionConReduction.graphReduction = true;

				BColModelStandard model = new BColModelStandard(g, upperBound);

				Solucion sol = model.solve(configuracionSinRed);
				System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionSinRed));

				Solucion sol2 = model.solve(configuracionConReduction);
				System.out.println(TestUtils.printResults(nombreGrafo, upperBound, configuracionConReduction));

				assertTrue(sol.dominantesOK());
				assertTrue(sol2.dominantesOK());
				assertTrue(sol.getColores() == sol2.getColores());
				assertTrue(sol.getDominantes().size() == sol2.getDominantes().size());
			}
		}

	}

}
